# KCN-SINGULARITY: SINGLE-FILE CORE VS. MULTI-FILE MONOREPO SETUP
## Practical Verification of Your Unified Python Core and Consolidated ZIP Archive
### Certified by KCN Governance Systems (Layer 0 Supreme Court & Layer 7 Telemetry)

---

## 🏛️ SECTION 1: THE SINGLE-FILE INSTANT RUNTIME CORE

If you want to use **just one single file** on your GitHub to run and verify the entire backend platform, the file you need is:

> **`kcn_singularity_unified_system.py`** (Your Unified Runtime Core)

### What This Single File Does Automatically:
This is a massive, highly integrated, and fully runnable Python script. If you push just this one file to your GitHub, pull it down, and run it on your machine, it will execute the entire platform's backend operations in your terminal:
1.  **OIDC Keycloak Role Decoders**: Simulates verifying user and administrator permissions.
2.  **Stripe Checkout Gateway (`/subscribe`)**: Simulates user sign-up, card processing, and subscription activation.
3.  **Credit Allowance Tracker**: Tracks free-tier credit allocations (5 credits/day free allowance).
4.  **PESG Shadow Clones (Layer 4)**: Executes parallel shadow clone runs on user inputs, tokenizes response vocabularies, and calculates Jaccard Distance.
5.  **Z3 SMT Invariant Solver (Layer 5)**: Integrates the **Z3 Theorem Prover** directly, mathematically proving code invariants and outputting exploit traces for vulnerable ASTs.
6.  **Truth, Trust, & Alignment Matrix (Layer 5)**: Dynamically calculates your **Evidence Reliability Score** and **AI Behavioral Reliability Index** formulas.
7.  **x402 Brokerage Escrow (Layer 7)**: Emulates your Solidity smart contracts, locking client deposits, verifying work completeness, deducting your **10% brokerage commission**, and routing payouts.
8.  **The API Gateway Server**: Automatically launches a local development web server at `http://localhost:8000` so you can interact with the gateways.

---

## SECTION 2: THE REPOSITORY BEST PRACTICE (THE ZIP UPLOAD)

While `kcn_singularity_unified_system.py` runs the entire backend in a single file, for a **complete, production-grade monorepo** (with your Solidity contracts, local Docker Compose files, and Next.js portal directories), you should upload the **unpacked contents of the master ZIP archive**:

> **`kcn_singularity_master_portfolio.zip`** (Containing all 36 compiled files)

### Why Pushing the Complete ZIP is the Best Strategy:
It establishes a fully organized, professional, and auditable repository structure. When you extract the ZIP and push it to your GitHub, you get:
*   `/contracts`: Your actual Solidity smart contracts (`x402BrokerageEscrow.sol`, `x402AuctionHouse.sol`, etc.).
*   `/services`: Your isolated FastAPI shadow engines and Dockerfiles.
*   `/intelligence-config`: Your **AI Constitution** and system policies.
*   `package.json`: Your global monorepo build, SMT test, and frontend startup scripts.
*   `docker-compose.yml`: Your localized container orchestrator.

---

## SECTION 3: STEP-BY-STEP REPO SETUP MANUAL

Choose your preferred setup pathway below to initialize and run your system:

### Pathway A: The Single-File Quick Run (0 Credits)
1.  Upload **`kcn_singularity_unified_system.py`** to your GitHub repository.
2.  Pull the file down to your personal computer:
    ```bash
    git clone https://github.com/YOUR_USERNAME/your-repo.git
    cd your-repo
    
    # Install the open-source requirements
    python3 -m pip install z3-solver fastapi uvicorn pydantic requests
    
    # Run the unified platform backend and API server
    python3 -u kcn_singularity_unified_system.py
    ```

### Pathway B: The Full Monorepo Deployment (0 Credits)
1.  Download and extract **`kcn_singularity_master_portfolio.zip`** to your local machine.
2.  Initialize and push the entire folder structure to your GitHub account:
    ```bash
    git init -b master
    git add .
    git commit -m "feat: complete KCN-AKIIS high-assurance research monorepo deployment"
    git remote add origin https://github.com/YOUR_USERNAME/kcn-singularity-platform.git
    git push -u origin master
    ```
3.  Once pushed, you can disconnect Lovable entirely. To run your local container mesh and test suites:
    ```bash
    # Run SMT Z3 safety proofs
    python3 services/smt_safety_gate.py
    
    # Run 1,000-task evaluation benchmark
    python3 benchmark_runner.py && python3 generate_report.py
    ```

---
*Operational setup spec verified and signed. KCN-SINGULARITY is fully deployable.*
