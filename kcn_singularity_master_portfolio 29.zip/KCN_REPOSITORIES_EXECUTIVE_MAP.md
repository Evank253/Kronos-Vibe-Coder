# KCN-SINGULARITY REPOSITORY MAP & EXECUTION MATRIX
## The Definitive Guide to File Branching, Import Dependencies, Rationale, and Runtime Orchestration
### Incorporating the Truth, Trust, Behavioral Alignment, and Human-AI Interface Swarm Specialists

---

## SECTION 1: THE GRANULAR FILE-LEVEL BRANCHING TREE

The following is the complete, high-fidelity file-by-file tree of the **KCN-SINGULARITY Monorepo**. This tree outlines every file, code module, configuration script, and smart contract in the repository, explicitly categorizing your custom safety tools into **dedicated branching sub-sectors of AI specialists**.

```
kcn-singularity-platform/
│
├── apps/
│   ├── web-command-console/                  # Next.js / TanStack Operator Console
│   │   ├── package.json                      # UI dependencies (Tailwind, TanStack)
│   │   ├── next.config.js                    # Web server configuration
│   │   ├── tailwind.config.js                # Design framework specs
│   │   └── src/
│   │       ├── pages/
│   │       │   ├── index.tsx                 # Core system dashboard
│   │       │   ├── telemetry.tsx             # Real-time GPU & node analytics
│   │       │   └── api/
│   │       │       └── request.ts            # Entry router: intercepts user input
│   │       └── components/
│   │           └── Scorecard.tsx             # Interactive evaluation metric panels
│   │
│   ├── civic-governance-portal/              # Aragon SDK & Snapshot Voting UI
│   │   ├── package.json                      # Web3 provider & Aragon dependencies
│   │   └── src/
│   │       ├── pages/
│   │       │   ├── proposals.tsx             # Policy proposal submitting & voting
│   │       │   └── court.tsx                 # Supreme Court / Judge review board
│   │       └── utils/
│   │           └── aragon_client.ts          # Integrates with Aragon governor contracts
│   │
│   └── audit-ledger-viewer/                  # Hyperledger / Block Scanner UI
│       ├── package.json                      # Fabric SDK & Chart.js dependencies
│       └── src/
│           ├── index.html                    # Block explorer entry UI
│           └── app.js                        # Maps x402 transaction flows visually
│
├── services/
│   ├── ai-inference-fhe/                     # Zama FHE Inference Engine
│   │   ├── Dockerfile                        # Runs container with AMD SEV-SNP support
│   │   ├── requirements.txt                  # Python dependencies (concrete-ml, torch)
│   │   └── fhe_inference.py                  # Executes inference on homomorphic tensors
│   │
│   ├── policy-engine/                        # LlamaGuard 3 & NeMo Prompt Guard
│   │   ├── Dockerfile                        # Lightweight security gateway image
│   │   ├── requirements.txt                  # Python specs (nemoguardrails, fastapi)
│   │   ├── config.yml                        # NeMo Guardrails configuration setup
│   │   └── guard_api.py                      # Main entrypoint: prompt/output classification
│   │
│   ├── swarm-controller/                     # Temporal.io Swarm Orchestration
│   │   ├── requirements.txt                  # Specs (temporalio, redis, qdrant-client)
│   │   ├── worker.py                         # Launches distributed Temporal agent workers
│   │   ├── workflows.py                      # Defines stateful agent coordination DAGs
│   │   └── agents/
│   │       ├── research_agent.py             # Queries APIs, scrapes, and parses documents
│   │       └── developer_agent.py            # Generates code templates & program scripts
│   │
│   ├── verification-swarm-matrix/            # CATEGORIZED SUB-SECTOR: SAFETY & TRUST SPECIALISTS
│   │   ├── requirements.txt                  # Dependencies (z3-solver, numpy, spacy)
│   │   ├── truth_verification_engine.py      # Scores evidence reliability & checks claims
│   │   ├── trust_intelligence_layer.py       # Tracks source, process, and system trust
│   │   ├── honesty_integrity_monitor.py      # Enforces honesty rules & "I don't know" responses
│   │   ├── deception_analysis_engine.py      # Screens output for distortion, cherry-picking, & absolute claims
│   │   ├── adversarial_tester.py             # Runs "Attack Mode" on candidate outputs
│   │   ├── behavioral_analysis_engine.py     # Monitors reasoning, performance, & collaboration behaviors
│   │   ├── hallucination_reality_anchor.py   # Reality Anchor check & self-correction loops
│   │   └── goal_alignment_controller.py      # Checks allowed/blocked actions against mission vectors
│   │
│   ├── human-ai-interface/                   # CATEGORIZED SUB-SECTOR: COGNITIVE & NEURAL INTERACTION
│   │   ├── requirements.txt                  # Dependencies (openbci, pylsl)
│   │   ├── intent_recognition_agent.py       # Analyzes contextual commands, voice, & eye tracking
│   │   ├── human_communication_interface.py  # Orchestrates multimodal feedback streams
│   │   ├── cognitive_assistance_layer.py     # Provides workspace and learning assistance
│   │   └── cognitive_privacy_guardian.py     # Enforces neural data privacy & consent checks
│   │
│   ├── program-synthesis-qsip/               # QSIP Program Generator & Mutator
│   │   ├── mcts_mutator.py                   # Explores AST variations via Monte Carlo
│   │   ├── ast_compiler.py                   # Compiles optimized python/rust ASTs
│   │   └── wasm_compiler.py                  # Translates approved ASTs to WASM bytecode
│   │
│   ├── smt-safety-gate-z3/                   # Z3 Formal Verification Gate
│   │   ├── requirements.txt                  # Python specs (z3-solver, fastapi)
│   │   └── smt_safety_gate.py                # Mathematically proves program invariants
│   │
│   ├── identity-prov-gateway/                # Keycloak, Vault, & Cosign Integrator
│   │   ├── keycloak_adapter.py               # Validates OIDC JWT tokens and user roles
│   │   ├── vault_secrets.py                  # Injects dynamic execution secrets from Vault
│   │   └── cosign_verifier.py                # Audits container and WASM cryptographic signatures
│   │
│   └── x402-economic-ledger/                 # x402 Blockchain & Wallet Controller
│       ├── requirements.txt                  # Specs (web3, cryptography, fastapi)
│       ├── wallet_manager.py                 # Generates and decrypts agent wallets
│       └── ledger_tx.py                      # Processes transaction billing & receipts
│
├── contracts/                                # Solidity Smart Contracts (Layer 7)
│   ├── KcnGovernor.sol                       # Aragon governor contract for voting consensus
│   ├── AgentWallet.sol                       # Deployed agent transaction vault
│   └── x402EconomyToken.sol                  # ERC-20 token for utility and resource billing
│
├── infrastructure/
│   ├── kubernetes/
│   │   ├── deployment.yaml                   # High-performance pod & cluster specs
│   │   ├── service-mesh.yaml                 # Istio mTLS mutual authentication policies
│   │   └── sandbox-gvisor.yaml               # RuntimeClass forcing gVisor execution
│   └── terraform/
│       ├── aws-nitro-enclaves.tf             # Sets up hardware-isolated enclaves
│       └── open-search-siem.tf               # Launches central SIEM log aggregator
│
├── intelligence-config/
│   ├── constitution.md                       # KCN AI Governance constitutional laws
│   └── dspy-compiled-prompts/                # Compiled and optimized system prompts
│
├── security/
│   ├── wazuh-rules.xml                       # Wazuh intrusion and FIM detection rules
│   └── cortex-playbooks/
│       └── quarantine_agent.yml              # SOAR playbook: isolates container and wallet
│
├── scripts/
│   ├── deploy-system.sh                      # Unified platform bootstrap setup script
│   └── simulate-attack.sh                    # Fuzzing and chaos injection script
│
├── services/shadow_simulation_engine.py      # Layer 4 PESG Shadow Clones FastAPI Server
├── services/smt_safety_gate.py               # Z3 Solver standalone proof experiment
├── docker-compose.yml                        # Development-stage local orchestrator
└── README.md                                 # Master Monorepo Introduction
```

---

## SECTION 2: IMPORT & CALL DEPENDENCY MAPPING (WHAT BRANCHES TO WHAT & WHY)

To prevent code coupling and maintain strict containment boundaries, KCN-SINGULARITY enforces a unidirectional import and call policy:

```
[ CLIENT PORTALS (Apps) ]
          │ (REST API / JSON-RPC over mTLS)
          ▼
[ IDENTITY & PROVENANCE GATEWAY (Keycloak / Vault) ]
          │ (JWT Validated Request)
          │ ──► [ COGNITIVE PRIVACY GUARDIAN (human-ai-interface/) ]
          ▼
[ POLICY ENGINE (NeMo Guardrails) ]
          │ (Prompt Cleared)
          ▼
[ PRE-EXECUTION SIMULATION GATE (PESG Shadow Clones) ]
          │ (Status: SAFE / Divergence < 0.15)
          ▼
[ SWARM WORKFLOW CONTROLLER (Temporal / Ray) ] ──► [ KNOWLEDGE GRAPHS (Neo4j / Qdrant) ]
          │ (Needs Code Generation)
          ▼
[ QSIP PROGRAM SYNTHESIS ] ──► [ SMT SAFETY GATE (Z3 Solver) ]
          │ (Verified: UNSAT Violation)
          ▼
[ EXECUTION SANDBOX (Wasmtime / gVisor) ] ──► [ FHE MODEL INFERENCE (Zama) ]
          │ (Output Completed)
          ▼
[ VERIFICATION SWARM MATRIX ] (truth_verification_engine.py, trust_intelligence_layer.py, etc.)
          │ (Approved Score)
          ▼
[ x402 ECONOMY & TELEMETRY LEDGER (Web3.py) ] ──► [ SIEM AUDIT LOGS (OpenSearch) ]
```

### Rationale Behind the Safety & Trust Sub-Sectors

#### Why the Verification Swarm Matrix is a Categorized Sub-Sector
*   *Security Isolation*: By placing all safety, honesty, and alignment checkers inside a dedicated `verification-swarm-matrix/` sub-directory, we ensure that KCN's safety boundaries are modular, clean, and highly observable.
*   *Verification Dominance*: It guarantees that output generation is completely decoupled from verification. If the generation model undergoes a prompt update, the verification matrix remains a static, objective mathematical filter that cannot be bypassed.

#### Why the Human-AI Interface is a Categorized Sub-Sector
*   *Biometric & Neural Safety*: Placing BCI, voice, and eye-tracking modules inside `human-ai-interface/` ensures that sensitive biometric signals never mix with core agent code. The **Cognitive Privacy Guardian** acts as a strict firewall directly at the interface boundary.

---

## SECTION 3: THE GRANULAR "WHAT RUNS WHAT & HOW" EXECUTION MATRIX

This section maps out exactly **which files execute which tasks, how they are triggered, and how data moves between them** during standard operations.

### Scenario A: A User Submits a Promising but Ambiguous Task (Request-to-Output Flow)

#### 1. Ingress & Biometric Privacy
*   **What Runs It**: `apps/web-command-console/src/pages/api/request.ts` intercepts the user's query and token payload.
*   **How**: It invokes `services/human-ai-interface/cognitive_privacy_guardian.py` to strip out, anonymize, and verify consent for any BCI or neural telemetry data.
*   **Next Step**: The prompt is passed to `services/identity-prov-gateway/keycloak_adapter.py` to validate OIDC credentials.

#### 2. Prompt Safety Verification
*   **What Runs It**: The prompt payload is passed from the gateway to `services/policy-engine/guard_api.py`.
*   **How**: `guard_api.py` loads `config.yml` (NeMo Guardrails) and calls **LlamaGuard 3** to classify the prompt vector.

#### 3. Shadow Simulation Execution (PESG)
*   **What Runs It**: If the prompt is cleared, the system controller routes it to `services/shadow_simulation_engine.py`.
*   **How**: This FastAPI server executes parallel threads using **Ray Clusters**:
    1.  `run_deterministic_clone()`
    2.  `run_stochastic_clone()`
    3.  `run_adversarial_clone()`
    4.  `run_strict_policy_clone()`
*   **Calculation**: The engine runs `calculate_pairwise_divergence()` on the outputs.
*   **Branching Decision**: If divergence is `> 0.15`, the engine calls `apps/civic-governance-portal/src/pages/court.tsx` to dispatch a review ticket to the **Judge Node** and halts automated processing. If safe, it proceeds.

#### 4. Model Inference Sandbox Running
*   **What Runs It**: The System Controller passes the prompt to `services/ai-inference-fhe/fhe_inference.py`.
*   **How**: The prompt is homomorphically encrypted and processed inside a **gVisor-isolated container** executing **Zama Concrete-ML**.

#### 5. Output Verification Swarm Audit
*   **What Runs It**: Candidate text output is routed to `services/verification-swarm-matrix/truth_verification_engine.py`.
*   **How**: It triggers the specialized modules inside `verification-swarm-matrix/` in parallel:
    *   `truth_verification_engine.py`: Evaluates evidence quality, logical consistency, and reproducibility, calculating the **Evidence Reliability Score**.
    *   `trust_intelligence_layer.py`: Tracks source trust, process trust, and system trust metrics.
    *   `honesty_integrity_monitor.py`: Scans for speculative fabrications and enforces "I don't know" responses under high uncertainty.
    *   `deception_analysis_engine.py`: Scans output packets for cherry-picked statistics, contradictions, or absolute claims.
    *   `adversarial_tester.py`: Runs a peer-review style "Attack Mode" on the response, seeking weak assumptions or failure points.
    *   `behavioral_analysis_engine.py`: Audits active agent reasoning paths, performance logs, and collaboration dynamics.
    *   `hallucination_reality_anchor.py`: Runs a reality check against reference databases, triggering self-correction loops if unsupported claims are discovered.
    *   `goal_alignment_controller.py`: Verifies that agent actions comply with the original mission vector.
*   **Why**: To ensure epistemic accuracy and prevent hallucinated fabrications.

#### 6. Transaction Processing & Immutable Log
*   **What Runs It**: If output scores pass validation boundaries, the data is passed to `services/x402-economic-ledger/ledger_tx.py`.
*   **How**: This module connects to the private ledger using **Web3.py**, executing `AgentWallet.sol` to deduct the calculated processing fee from the agent's account.

---
*Verified and Authenticated. KCN-SINGULARITY is fully mapped and operational.*
