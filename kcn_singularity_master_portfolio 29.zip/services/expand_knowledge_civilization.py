import os

def expand_kcn_knowledge_civilization():
    print("=" * 80)
    print(" EXPANDING KCN-AKIIS KNOWLEDGE CIVILIZATION DATABASE (NEW FRONTIER DOMAINS)")
    print("=" * 80)

    # Define the new requested domain sectors and their highly detailed, rich Knowledge Slabs
    new_domains = {
        "domains/03_engineering": {
            "file": "knowledge_slab_construction.md",
            "content": """# KCN CIVIL ENGINEERING & CONSTRUCTION KNOWLEDGE SLAB
## Category Index: 03_engineering (Sub-Sector: Construction)
## Core Axioms: Structural Loading, Shear Force, Beam Deflection, and Material Tolerances

### 1. STRUCTURAL LOADING EQUATIONS
To ensure structural integrity in KCN-designed physical facilities, we calculate total dead load ($D$) and live load ($L$):

$$U = 1.2D + 1.6L$$

Where $U$ is the ultimate design load required under structural design codes (ACI 318).

### 2. BEAM DEFLECTION & ELASTICITY
We model the deflection ($\delta$) of a simply supported beam under a concentrated central load ($P$):

$$\delta_{\text{max}} = \frac{PL^3}{48EI}$$

Where:
*   $P$ is the applied central load.
*   $L$ is the length of the span.
*   $E$ is Modulus of Elasticity of the material.
*   $I$ is Area Moment of Inertia of the cross-section.

### 3. CONCRETE STRESS-STRAIN TENSORS
To model concrete reinforcement boundaries, we evaluate the compressive stress-strain profile using the Whitney stress block representation:

$$a = \beta_1 \cdot c$$

Where:
*   $a$ is the depth of the equivalent rectangular stress block.
*   $c$ is the distance from the extreme compression fiber to the neutral axis.
*   $\beta_1$ is a reduction factor ranging from 0.65 to 0.85 based on compressive strength ($f'_c$).
"""
        },
        "domains/03_engineering_architecture": {
            "file": "knowledge_slab_architecture.md",
            "content": """# KCN ARCHITECTURE & SPATIAL DESIGN KNOWLEDGE SLAB
## Category Index: 03_engineering_architecture
## Core Axioms: Golden Ratio Scaling, Circulation Graphs, and Acoustic Envelopes

### 1. THE GOLDEN RATIO SCALING ($\Phi$)
For aesthetic, balanced, and structural spatial scaling, we enforce the Fibonacci golden ratio:

$$\Phi = \frac{1 + \sqrt{5}}{2} \approx 1.6180339887$$

Any structural panel or window frame designed by the *Architecture Swarm* must satisfy:

$$\frac{A + B}{A} = \frac{A}{B} = \Phi$$

### 2. CIRCULATION PATHWAY GRAPHS
We model building occupant circulation flows as weighted directed graphs $G = (V, E)$. Vertices ($V$) represent spatial rooms, and edges ($E$) represent doors/corridors:

$$\text{Circulation Efficiency} = \sum_{i,j \in V} \frac{\text{Traffic\_Volume}(i, j)}{\text{Path\_Distance}(i, j)}$$

The system runs Dijkstra's shortest-path algorithm to optimize emergency evacuation routes and minimize hallway congestion.

### 3. ACOUSTIC REFLECTION & REVERBERATION (SABINE FORMULA)
To optimize acoustic envelopes inside auditorium designs, we calculate reverberation time ($RT_{60}$):

$$RT_{60} = \frac{0.161 \cdot V}{A}$$

Where:
*   $V$ is the room volume (in cubic meters).
*   $A$ is total absorption (Sabins), calculated as $A = \sum S_i \alpha_i$ (Surface Area times Absorption Coefficient).
"""
        },
        "domains/31_manufacturing_logistics": {
            "file": "knowledge_slab_production.md",
            "content": """# KCN PRODUCTION & MANUFACTURING KNOWLEDGE SLAB
## Category Index: 31_manufacturing_logistics (Sub-Sector: Production)
## Core Axioms: Toyota Production System (TPS), Little's Law, and Six Sigma Quality Metrics

### 1. LITTLE'S LAW (THROUGHPUT RUNS)
To optimize assembly lines, KCN-AKIIS evaluates work-in-progress (WIP) inventories using Little's Law:

$$L = \lambda \cdot W$$

Where:
*   $L$ is average number of items in the manufacturing system.
*   $\lambda$ is the average arrival rate of raw materials.
*   $W$ is average time an item spends in the system (Cycle Time).

### 2. TAKT TIME (DEMAND BALANCE)
We align manufacturing speeds with consumer demand using Takt Time:

$$T_{\text{takt}} = \frac{\text{Available Production Time}}{\text{Customer Demand Rate}}$$

### 3. SIX SIGMA DEFECT RATIOS
To guarantee manufacturing precision, the *Engineering Swarm* calculates Defects Per Million Opportunities (DPMO):

$$\text{DPMO} = \frac{\text{Total Defects} \times 1,000,000}{\text{Total Units} \times \text{Opportunities Per Unit}}$$

*Six Sigma Target*: Achieving **3.4 DPMO** (equivalent to 99.99966% defect-free manufacturing).
"""
        },
        "domains/37_arts_and_media": {
            "file": "knowledge_slab_filmmaking.md",
            "content": """# KCN FILMMAKING & THEATER KNOWLEDGE SLAB
## Category Index: 37_arts_and_media
## Core Axioms: Rule of Thirds, Three-Act Narrative Structures, and Lens Optics

### 1. CINEMATIC COMPOSITION & THE RULE OF THIRDS
For visual framing, the *Creative Agent* divides the camera viewport into a $3 \times 3$ grid. Points of interest must lie at the intersections of the horizontal and vertical dividing lines:

$$x_{\text{grid}} \in \left\{ \frac{W}{3}, \frac{2W}{3} \right\} \quad \land \quad y_{\text{grid}} \in \left\{ \frac{H}{3}, \frac{2H}{3} \right\}$$

### 2. CAMERA LENS OPTICS & DEPTH OF FIELD
We model camera lens focal length ($f$) and aperture ($N$-stop) to calculate Depth of Field (DoF):

$$\text{Hyperfocal Distance: } H = \frac{f^2}{N \cdot c} + f$$

Where $c$ is the circle of confusion limit.

### 3. THREE-ACT THEATRICAL STRUCTURE
To write compelling narrative scripts, the *Creative Agent* structures plot pacing using the classical Aristotelian Three-Act template:
*   **Act I (Setup)**: 0% to 25% of timeline. Climax 1 occurs at the 25% point.
*   **Act II (Confrontation)**: 25% to 75% of timeline. Midpoint climax occurs at the 50% point.
*   **Act III (Resolution)**: 75% to 100% of timeline. Final climax occurs at the 90% point.
"""
        },
        "domains/27_psychology": {
            "file": "knowledge_slab_emotions.md",
            "content": """# KCN BEHAVIOR & EMOTION KNOWLEDGE SLAB
## Category Index: 27_psychology
## Core Axioms: Plutchik's Wheel, Cognitive Behavioral Paradigms, and Autonomic Telemetry

### 1. PLUTCHIK'S WHEEL OF EMOTIONAL TRANSFORMS
We represent human emotional states as vectors in a 3D polar coordinate space based on Plutchik's model. Emotions are categorized into 8 primary bipolar dyads:
*   Joy vs. Sadness
*   Anger vs. Fear
*   Trust vs. Disgust
*   Anticipation vs. Surprise

The system maps secondary emotions as vector additions (e.g., $\text{Love} = \text{Joy} + \text{Trust}$).

### 2. COGNITIVE BEHAVIORAL THERAPY (CBT) LOOPS
We model human behavior loops using the Cognitive Triad:

$$\text{Thought} \rightarrow \text{Feeling} \rightarrow \text{Behavior} \rightarrow \text{Thought}$$

If a user exhibits negative cognitive bias during BCI telemetry runs, the *Cognitive Assistance Agent* runs positive restructuring filters.

### 3. AUTONOMIC NERVOUS SYSTEM (ANS) TELEMETRY
To monitor operator stress during high-stakes maneuvers, KCN analyzes biometric heart rate variability (HRV):

$$\text{RMSSD} = \sqrt{\frac{1}{N-1} \sum_{i=1}^{N-1} (RR_{i+1} - RR_i)^2}$$

Where $RR_i$ is the time interval between consecutive heartbeats. Low HRV (RMSSD < 20ms) triggers automated stress-reduction UI modulations.
"""
        },
        "domains/38_landscaping_and_design": {
            "file": "knowledge_slab_landscaping.md",
            "content": """# KCN LANDSCAPING & SOIL ECOLOGY KNOWLEDGE SLAB
## Category Index: 38_landscaping_and_design
## Core Axioms: Hydrologic Runoff, Soil pH Chemistry, and Plant Microclimates

### 1. HYDROLOGIC RUNOFF LAW (THE RATIONAL METHOD)
To design efficient landscape drainage and grading systems, we calculate peak storm runoff rate ($Q$):

$$Q = C \cdot I \cdot A$$

Where:
*   $Q$ is peak runoff rate (in cubic feet per second).
*   $C$ is dimensionless runoff coefficient (ranging from 0.1 for sandy lawns to 0.9 for asphalt).
*   $I$ is rainfall intensity (inches per hour).
*   $A$ is drainage area (acres).

### 2. SOIL pH & NITROGEN-PHOSPHORUS-POTASSIUM (NPK) CHEMISTRY
The *Landscaping Agent* evaluates soil chemical profiles. Plant growth requires optimal pH ranges (typically 6.0 to 7.0) to facilitate nutrient uptake:

$$\text{NPK Optimal Ratio (Lawn): } 4 : 1 : 2 \quad \text{NPK Optimal Ratio (Garden): } 1 : 2 : 1$$

### 3. MICROCLIMATE TEMPERATURE THERMAL LOOPS
We model physical temperature modulations caused by shade trees using the transpiration cooling equation:

$$\Delta T = \frac{\lambda \cdot E_{\text{trans}}}{C_p \cdot \rho \cdot V}$$

Where:
*   $\lambda$ is latent heat of vaporization of water.
*   $E_{\text{trans}}$ is tree water transpiration rate.
*   $C_p \cdot \rho$ is volumetric heat capacity of air.
*   $V$ is localized wind volume.
"""
        }
    }

    # Write each new Knowledge Slab to its respective folder in the workspace
    for path, data in new_domains.items():
        os.makedirs(path, exist_ok=True)
        file_path = os.path.join(path, data["file"])
        
        with open(file_path, 'w') as f:
            f.write(data["content"])
            
        print(f"  ✔ Created: {file_path}")

    print("\n" + "=" * 80)
    print("✔ All new multi-disciplinary Knowledge Slabs written and integrated!")
    print("=" * 80)

if __name__ == "__main__":
    expand_kcn_knowledge_civilization()
