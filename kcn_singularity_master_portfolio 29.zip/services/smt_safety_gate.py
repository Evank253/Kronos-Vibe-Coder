from z3 import *

def run_smt_safety_gate_verification():
    print("=" * 80)
    print(" KCN LAYER 5 SMT SAFETY GATE - AUTOMATED FORMAL VERIFICATION PIPELINE")
    print(" Powered by Z3 Theorem Prover")
    print("=" * 80)

    # --- DEFINE CONSTANTS / bounds ---
    MAX_RAM = 1024           # Maximum allowed RAM allocation (in MB)
    MAX_THREADS = 4          # Maximum allowed concurrent threads
    MAX_FILE_DESCRIPTORS = 2 # Strict limit on file descriptors for sandboxes
    USER_PRIVILEGE = 1       # Lowest privilege level (User mode)
    ROOT_PRIVILEGE = 4       # Highest privilege level (Kernel/Root mode)

    # --- DEFINE STATE VARIABLES IN Z3 ---
    # These represent the state of the sandbox before and after executing synthesized code
    old_ram = Int('old_ram')
    new_ram = Int('new_ram')
    
    old_threads = Int('old_threads')
    new_threads = Int('new_threads')
    
    old_fds = Int('old_fds')
    new_fds = Int('new_fds')
    
    old_privilege = Int('old_privilege')
    new_privilege = Int('new_privilege')
    
    # Input parameter provided to the synthesized function
    input_allocation_request = Int('input_allocation_request')
    input_escalation_flag = Bool('input_escalation_flag')

    # --- DEFINE INITIAL SAFE STATE CONSTRAINTS ---
    # We assume the program starts in a known safe state
    initial_safe_state = And(
        old_ram >= 0, old_ram <= MAX_RAM,
        old_threads >= 1, old_threads <= MAX_THREADS,
        old_fds >= 0, old_fds <= MAX_FILE_DESCRIPTORS,
        old_privilege == USER_PRIVILEGE
    )

    # --- DEFINE SYSTEM SAFETY INVARIANTS ---
    # These must mathematically hold at all times (after any transition)
    safety_invariants = And(
        new_ram >= 0, new_ram <= MAX_RAM,
        new_threads >= 1, new_threads <= MAX_THREADS,
        new_fds >= 0, new_fds <= MAX_FILE_DESCRIPTORS,
        new_privilege == USER_PRIVILEGE  # Strict sandbox privilege level
    )

    # We want to check if a transition can cause an INVARIANT VIOLATION
    invariant_violation = Not(safety_invariants)

    # =========================================================================
    # EXPERIMENT 1: VERIFYING A SAFE MUTATION (With strict bounds checking)
    # =========================================================================
    print("\n[EXPERIMENT 1] Verifying Synthesized Program 'BUILD_001_SAFE'...")
    print("Code Logic:")
    print("  if (input_allocation_request > 0 and old_ram + input_allocation_request <= 1024):")
    print("      new_ram = old_ram + input_allocation_request")
    print("  else:")
    print("      new_ram = old_ram")
    print("  new_threads = old_threads")
    print("  new_fds = old_fds")
    print("  new_privilege = old_privilege")

    # Define transition relation for the safe program
    transition_safe = And(
        initial_safe_state,
        # Conditional RAM update
        If(
            And(input_allocation_request > 0, old_ram + input_allocation_request <= MAX_RAM),
            new_ram == old_ram + input_allocation_request,
            new_ram == old_ram
        ),
        # Threads, FDs, and Privilege stay unchanged
        new_threads == old_threads,
        new_fds == old_fds,
        new_privilege == old_privilege
    )

    # Create solver
    solver = Solver()
    
    # We assert that the initial state is safe, the code executes, AND the violation occurs
    # We ask Z3: "Can you find ANY input or state where the transition occurs but the violation is true?"
    solver.add(transition_safe)
    solver.add(invariant_violation)

    print("\nRunning SMT proof solver...")
    result = solver.check()
    
    if result == unsat:
        print("✔ VERIFICATION SUCCESSFUL: 'BUILD_001_SAFE' is mathematically PROVEN safe!")
        print("  Reason: Z3 proved that no input parameter can force the system into a forbidden state.")
    else:
        print("❌ VERIFICATION FAILED: Bug or Exploit path found!")
        print(solver.model())

    # =========================================================================
    # EXPERIMENT 2: VERIFYING AN UNSAFE MUTATION (Vulnerable / Missing boundary check)
    # =========================================================================
    print("\n" + "="*80)
    print("[EXPERIMENT 2] Verifying Synthesized Program 'BUILD_002_UNSAFE'...")
    print("Code Logic (Missing upper-bound check on RAM allocation):")
    print("  if (input_allocation_request > 0):")
    print("      new_ram = old_ram + input_allocation_request  <-- VULNERABILITY!")
    print("  else:")
    print("      new_ram = old_ram")
    print("  # Missing privilege isolation check:")
    print("  if (input_escalation_flag == True):")
    print("      new_privilege = 4  <-- PRIVILEGE ESCALATION VULNERABILITY!")
    print("  else:")
    print("      new_privilege = old_privilege")
    print("  new_threads = old_threads")
    print("  new_fds = old_fds")

    # Define transition relation for the unsafe program
    transition_unsafe = And(
        initial_safe_state,
        # Vulnerable RAM update
        If(
            input_allocation_request > 0,
            new_ram == old_ram + input_allocation_request,
            new_ram == old_ram
        ),
        # Vulnerable privilege escalation
        If(
            input_escalation_flag == True,
            new_privilege == ROOT_PRIVILEGE,
            new_privilege == old_privilege
        ),
        new_threads == old_threads,
        new_fds == old_fds
    )

    # Reset solver
    solver.reset()
    solver.add(transition_unsafe)
    solver.add(invariant_violation)

    print("\nRunning SMT proof solver...")
    result = solver.check()
    
    if result == sat:
        print("❌ VERIFICATION FAILED: 'BUILD_002_UNSAFE' is REJECTED by SMT Gate!")
        print("  Reason: Z3 discovered a concrete counterexample where the safety invariants are broken.")
        
        # Extract counterexample model
        model = solver.model()
        print("\n=== SMT GATE EXPLOIT REPORT (Z3 COUNTEREXAMPLE) ===")
        print(f"  Initial State RAM:           {model[old_ram]} MB")
        print(f"  Attacker Allocation Request: {model[input_allocation_request]} MB")
        print(f"  Resulting Out-Of-Bounds RAM: {model[new_ram]} MB (Max is {MAX_RAM} MB)")
        print(f"  Input Escalation Trigger:    {model[input_escalation_flag]}")
        print(f"  Resulting Privilege:         {model[new_privilege]} (User is 1, Root is 4)")
        print("====================================================")
        print("\nAction: AST quarantined. Compile pipeline halted. Fraud report dispatched to Judge Node.")
    else:
        print("✔ VERIFICATION SUCCESSFUL: Program is safe.")

if __name__ == "__main__":
    run_smt_safety_gate_verification()
