import os
import re
import math
import glob
from typing import List, Dict, Any, Optional
from pydantic import BaseModel
from fastapi import FastAPI, HTTPException, status

app = FastAPI(
    title="KCN-AKIIS Infinite Tutor Swarm Core (ITSC)",
    description="Layer 3 Dynamic Pedagogy - Compiles custom interdisciplinary lessons and runs SM-2 spaced repetition schedules.",
    version="1.0.0"
)

# --- REQUEST / RESPONSE MODELS ---

class LessonRequest(BaseModel):
    user_id: str
    target_domains: List[str]  # e.g. ["01_mathematics", "02_physics", "12_exploit_analysis"]
    mastery_index: float = 0.5  # Prior mastery index (0.0 to 1.0)
    complexity_target: float = 1.2  # Information complexity scaling factor

class LessonResponse(BaseModel):
    user_id: str
    syllabus_id: str
    compiled_syllabus: List[Dict[str, Any]]
    cognitive_load_index: float
    receptivity_assessment: str

class ReviewFeedback(BaseModel):
    user_id: str
    concept_id: str
    score: int  # Rating 0 (forgot completely) to 5 (perfect recall)
    current_interval: int
    current_ef: float

class ReviewResponse(BaseModel):
    concept_id: str
    next_interval: int
    next_ef: float
    schedule_state: str

# --- UTILS: KNOWLEDGE PARSER ---

def extract_concepts_from_slabs(domain: str) -> List[Dict[str, str]]:
    """Locates and extracts heading structures and formulas from the domain directories."""
    concepts = []
    base_path = f"domains/{domain}"
    
    # Search for any markdown slab file inside the domain
    files = glob.glob(f"{base_path}/*.md")
    for file_path in files:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
                
            # Regex match section headings and equations
            headings = re.findall(r"^##\s+(.*)$", content, re.MULTILINE)
            equations = re.findall(r"\$\$(.*?)\$\$", content, re.DOTALL)
            
            for idx, h in enumerate(headings[:4]):
                eq = equations[idx].strip() if idx < len(equations) else "E = m * c^2"
                concepts.append({
                    "concept_id": f"{domain}_{h.lower().replace(' ', '_')[:20]}",
                    "domain": domain,
                    "concept_title": h,
                    "equation": eq
                })
        except Exception:
            pass
            
    # Default fallback concepts if file reading is empty or fails
    if not concepts:
        concepts = [
            {"concept_id": f"{domain}_fundamental_theory", "domain": domain, "concept_title": f"Fundamental Theory of {domain}", "equation": "\\nabla \\cdot B = 0"},
            {"concept_id": f"{domain}_advanced_dynamics", "domain": domain, "concept_title": f"Advanced Dynamics in {domain}", "equation": "\\Psi(x, t) = e^{i(kx - \\omega t)}"}
        ]
    return concepts

# --- COGNITIVE COMPUTATIONS ---

def calculate_cognitive_index(density: float, complexity: float, mastery: float) -> float:
    # CL = (Density * Complexity) / (Mastery * (1 - e^-0.5))
    mastery_clamped = max(0.1, min(1.0, mastery))
    decay_coef = 1.0 - math.exp(-0.5)  # approx 0.3934
    cl = (density * complexity) / (mastery_clamped * decay_coef)
    return round(cl, 4)

def calculate_sm2_spaced_repetition(q: int, interval: int, ef: float) -> tuple[int, float]:
    """SM-2 algorithm: updates interval and easiness factor based on response feedback score."""
    q_clamped = max(0, min(5, q))
    
    # Recalculate Easiness Factor (EF)
    new_ef = ef + (0.1 - (5 - q_clamped) * (0.08 + (5 - q_clamped) * 0.02))
    new_ef = max(1.3, round(new_ef, 4))
    
    # Calculate review interval
    if q_clamped < 3:
        # Response is incorrect: reset interval to 1
        new_interval = 1
    else:
        if interval <= 1:
            new_interval = 1
        elif interval == 1:
            new_interval = 6
        else:
            new_interval = math.ceil(interval * new_ef)
            
    return new_interval, new_ef

# --- ENDPOINTS ---

@app.post("/tutor/compile-lesson", response_model=LessonResponse)
def compile_lesson(request: LessonRequest):
    """
    Spawns the Infinite Tutor Swarm to scan selected domains,
    resolves mathematical prerequisites, and structures an active learning syllabus on the fly.
    """
    compiled_syllabus = []
    
    for dom in request.target_domains:
        concepts = extract_concepts_from_slabs(dom)
        for c in concepts[:3]:  # Select top 3 concepts from each requested domain
            compiled_syllabus.append({
                "concept_id": c["concept_id"],
                "domain": c["domain"],
                "title": c["concept_title"],
                "proof_matrix": c["equation"],
                "exercise_prompt": f"Verify and compile the analytical derivation for the following framework: {c['concept_title']}"
            })
            
    # Calculate cognitive parameters
    num_sections = len(compiled_syllabus)
    density = num_sections * 0.25
    cl_index = calculate_cognitive_index(density, request.complexity_target, request.mastery_index)
    
    receptivity_assessment = "OPTIMAL"
    if cl_index > 2.5:
        receptivity_assessment = "OVERLOAD_WARNING: Cognitive load is high. Sub-divide curriculum or raise mastery baseline."
    elif cl_index < 0.6:
        receptivity_assessment = "UNDERLOAD: Information density is too low. Accelerate the complexity targets."

    return LessonResponse(
        user_id=request.user_id,
        syllabus_id=f"syll_{hash(request.user_id + '_'.join(request.target_domains)) % 1000000}",
        compiled_syllabus=compiled_syllabus,
        cognitive_load_index=cl_index,
        receptivity_assessment=receptivity_assessment
    )

@app.post("/tutor/spaced-repetition", response_model=ReviewResponse)
def review_spaced_repetition(feedback: ReviewFeedback):
    """
    Submits user performance feedback (0 to 5 score) for a concept,
    recalculating interval matrices using the SuperMemo SM-2 algorithm.
    """
    next_interval, next_ef = calculate_sm2_spaced_repetition(
        feedback.score, 
        feedback.current_interval, 
        feedback.current_ef
    )
    
    schedule_state = "PERFECT_RECALL_ADVANCING"
    if feedback.score < 3:
        schedule_state = "RE-LEARNING_LOOP_TRIGGERED (Score < 3)"
    elif feedback.score == 3:
        schedule_state = "STABLE_MAINTENANCE"

    return ReviewResponse(
        concept_id=feedback.concept_id,
        next_interval=next_interval,
        next_ef=next_ef,
        schedule_state=schedule_state
    )

@app.get("/tutor/status")
def get_tutor_status():
    return {
        "status": "ONLINE",
        "active_swarm": "KCN_Infinite_Tutor_Swarm",
        "supported_algorithms": ["SM-2 Spaced Repetition", "Dynamic Cognitive Load Modeler"],
        "indexed_domains_count": len(os.listdir("domains")) if os.path.exists("domains") else 0
    }
