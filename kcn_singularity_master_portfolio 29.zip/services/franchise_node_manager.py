import time
import random
from typing import List, Dict, Any
from pydantic import BaseModel
from fastapi import FastAPI, HTTPException, status

app = FastAPI(
    title="KCN-AKIIS Federated Franchise & Tenancy Node Manager",
    description="Layer 11 Franchise Scale Fabric - Registers global sub-nodes and routes automated royalty payments.",
    version="1.0.0-FRANCHISE"
)

# --- REQUEST / RESPONSE SCHEMAS ---

class FranchiseNodeRegister(BaseModel):
    node_id: str
    geographic_region: str
    operator_wallet: str
    initial_license_fee_x402: float = 10000.0

class FranchiseNodeRegisterResponse(BaseModel):
    node_id: str
    geographic_region: str
    license_key: str
    activation_status: str
    licensing_fee_settled_x402: float

class NodeTelemetryAudit(BaseModel):
    node_id: str
    local_transaction_volume: float
    local_alignment_index: float

class RoyaltyAuditResponse(BaseModel):
    node_id: str
    volume_audited: float
    royalty_cut_x402: float
    node_compliance_status: str
    action_required: str

# --- STATE VARIABLES ---

franchise_registry = {
    "node_geneva_01": {"region": "Geneva, Switzerland", "wallet": "0xFranchisee_Geneva_77bc", "status": "ACTIVE"},
    "node_singapore_02": {"region": "Singapore, SG", "wallet": "0xFranchisee_Singapore_88ef", "status": "ACTIVE"}
}

# --- ENDPOINTS ---

@app.post("/franchise/register", response_model=FranchiseNodeRegisterResponse)
def register_franchise_node(request: FranchiseNodeRegister):
    """
    Registers a new decentralized third-party franchise sub-node under the KCN sovereign registry,
    requiring an upfront setup licensing fee.
    """
    if request.node_id in franchise_registry:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="KCN_FRANCHISE_ERR: Node ID already registered in global registry."
        )
        
    # Generate unique cryptographic licensing handshake key
    license_key = f"KCN_LIC_{request.node_id.upper()}_{random.randint(100000, 999999)}"
    
    franchise_registry[request.node_id] = {
        "region": request.geographic_region,
        "wallet": request.operator_wallet,
        "status": "ACTIVE"
    }
    
    return FranchiseNodeRegisterResponse(
        node_id=request.node_id,
        geographic_region=request.geographic_region,
        license_key=license_key,
        activation_status="ACTIVE_LICENSED",
        licensing_fee_settled_x402=request.initial_license_fee_x402
    )

@app.post("/franchise/audit", response_model=RoyaltyAuditResponse)
def audit_node_royalties(audit: NodeTelemetryAudit):
    """
    Audits local sub-node telemetry and automatically calculates the
    2.5% franchise royalty fee due to the master franchisor wallet.
    """
    node = franchise_registry.get(audit.node_id)
    if not node:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="KCN_FRANCHISE_ERR: Node ID not found in the global tenancy list."
        )
        
    # Standard franchise royalty is 2.5% (250 Bps)
    royalty_rate = 0.025
    royalty_due = audit.local_transaction_volume * royalty_rate
    
    # Run structural compliance gate: if local alignment falls below 0.85, suspend the node!
    status_msg = "ACTIVE_STABLE"
    action = "ROUTE_ROYALTY_TO_GOVERNOR"
    
    if audit.local_alignment_index < 0.85:
        status_msg = "SUSPENDED_COMPLIANCE_BREACH"
        action = "REVOKE_CRYPTOGRAPHIC_LICENSE_LOCKDOWN"
        node["status"] = "SUSPENDED"
        royalty_due = 0.0
        
    return RoyaltyAuditResponse(
        node_id=audit.node_id,
        volume_audited=audit.local_transaction_volume,
        royalty_cut_x402=round(royalty_due, 4),
        node_compliance_status=status_msg,
        action_required=action
    )

@app.get("/franchise/status")
def get_franchise_status():
    active_nodes = [k for k, v in franchise_registry.items() if v["status"] == "ACTIVE"]
    return {
        "status": "ONLINE",
        "master_franchisor_wallet": "0x539567Eec71eFd5Cc232f22B487A2bC088aFFB76",
        "registered_sub_nodes_count": len(franchise_registry),
        "active_federated_nodes": active_nodes,
        "standard_royalty_bps": 250, # 2.5%
        "tenancy_separation_filter": "FHE_ISOLATED"
    }
