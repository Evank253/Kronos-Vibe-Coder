import math
import time
import random
from typing import Dict, Any
from pydantic import BaseModel
from fastapi import FastAPI, HTTPException, status

app = FastAPI(
    title="KCN-AKIIS Thermal, Cold Computing & Neutronic Combustor Manager",
    description="Layer 8 & 9 Energy and Thermal Core - Manages aneutronic fusion reactors and cryo-cold computing registers.",
    version="1.0.0-CRYO"
)

# --- CONFIG & SCHEMAS ---

class IgnitionRequest(BaseModel):
    fuel_flow_rate_mg_s: float = 12.5  # Fuel flow of Hydrogen-Boron
    laser_trigger_power_gw: float = 5.0

class CryoCoolingRequest(BaseModel):
    target_temp_mk: float = 1.5  # target temperature in milli-Kelvin

class CombustorStatusResponse(BaseModel):
    reactor_ignited: bool
    combustor_plasma_temp_k: float
    output_power_mw: float
    dec_efficiency_pct: float
    cryo_temp_mk: float
    landauer_limit_joules: float
    classical_cmos_loss_joules: float
    efficiency_gain_factor: float
    system_load_status: str

# --- STATE VARIABLES ---

class ThermalState:
    def __init__(self):
        self.reactor_ignited = True
        self.plasma_temp_k = 1.25e9  # 1.25 Billion Kelvin
        self.fuel_flow = 12.5
        self.output_power = 485.2  # MW
        self.dec_efficiency = 92.4  # %
        self.cryo_temp_mk = 1.5  # mK
        
thermal_core_state = ThermalState()

# --- ALGORITHMS ---

def compute_landauer_limit(temp_mk: float) -> tuple[float, float]:
    """Calculates thermodynamic bit-erasure limits: E = kB * T * ln(2)"""
    kb = 1.380649e-23  # Boltzmann constant
    temp_kelvin = temp_mk / 1000.0
    landauer_joules = kb * temp_kelvin * math.log(2.0)
    
    # Classical CMOS erasure cost at room temperature (300K) is approx 1e-12 Joules
    classical_loss = kb * 300.0 * math.log(2.0) * 1e6  # heavily dissipative
    gain_factor = classical_loss / landauer_joules if landauer_joules > 0 else 1e9
    return landauer_joules, classical_loss, gain_factor

# --- ENDPOINTS ---

@app.get("/thermal/status", response_model=CombustorStatusResponse)
def get_combustor_status():
    """Returns real-time thermodynamic, cold computing, and fusion reactor telemetry."""
    landauer, classical, gain = compute_landauer_limit(thermal_core_state.cryo_temp_mk)
    
    status_msg = "THERMALLY_REVERSIBLE_OPTIMAL"
    if thermal_core_state.cryo_temp_mk > 100.0:
        status_msg = "THERMAL_ENTROPY_LOSS_WARNING: Coolant temperature elevated."
    if not thermal_core_state.reactor_ignited:
        status_msg = "CRITICAL_GRID_DOWNTIME: Reactor offline. Running on battery enclaves."
        
    return CombustorStatusResponse(
        reactor_ignited=thermal_core_state.reactor_ignited,
        combustor_plasma_temp_k=thermal_core_state.plasma_temp_k if thermal_core_state.reactor_ignited else 0.0,
        output_power_mw=thermal_core_state.output_power if thermal_core_state.reactor_ignited else 0.0,
        dec_efficiency_pct=thermal_core_state.dec_efficiency,
        cryo_temp_mk=thermal_core_state.cryo_temp_mk,
        landauer_limit_joules=landauer,
        classical_cmos_loss_joules=classical,
        efficiency_gain_factor=gain,
        system_load_status=status_msg
    )

@app.post("/thermal/ignite", response_model=Dict[str, Any])
def ignite_reactor(request: IgnitionRequest):
    """Fires ultra-fast multi-gigawatt lasers to ignite the Hydrogen-Boron fusion reactor."""
    thermal_core_state.reactor_ignited = True
    thermal_core_state.fuel_flow = request.fuel_flow_rate_mg_s
    thermal_core_state.plasma_temp_k = 1.25e9 + (request.laser_trigger_power_gw * 1e7)
    thermal_core_state.output_power = 400.0 + (request.fuel_flow_rate_mg_s * 6.8)
    
    return {
        "status": "IGNITION_SUCCESS",
        "laser_trigger": "PETAWATT_PULSE_COMPLETE",
        "burn_state": "STEADY_STATE_FUSION_ESTABLISHED",
        "output_power_mw": thermal_core_state.output_power,
        "plasma_temperature_k": thermal_core_state.plasma_temp_k
    }

@app.post("/thermal/cool", response_model=Dict[str, Any])
def adjust_cooling(request: CryoCoolingRequest):
    """Sets target cryogenic temperatures for our superconducting computing nodes."""
    if request.target_temp_mk <= 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="KCN_THERMAL_ERR: Absolute zero (0 mK) cannot be physically reached."
        )
    thermal_core_state.cryo_temp_mk = request.target_temp_mk
    return {
        "status": "COOLING_GRID_RECONCILED",
        "cryo_temperature_milli_kelvin": thermal_core_state.cryo_temp_mk,
        "thermal_sink_interlock": "LOCKED_IN_SHIELD_GRID"
    }
