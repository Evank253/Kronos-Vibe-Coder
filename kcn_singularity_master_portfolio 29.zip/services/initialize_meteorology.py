import os

def initialize_meteorology_science():
    print("=" * 80)
    print(" INITIALIZING METEOROLOGY & WEATHER FORECASTING DOMAIN")
    print("=" * 80)

    meteorology_data = {
        "domains/29_climate_science": {
            "file": "knowledge_slab_meteorology.md",
            "content": """# KCN METEOROLOGY & WEATHER FORECASTING KNOWLEDGE SLAB
## Category Index: 29_climate_science (Sub-Sector: Meteorology)
## Core Axioms: Hydrostatic Balance, Geostrophic Wind Equations, and Numerical Weather Prediction (NWP)

### 1. THE HYDROSTATIC EQUATION (PRESSURE-ALTITUDE DYNAMICS)
To model vertical atmospheric pressure layers, KCN evaluates the hydrostatic equilibrium equation:

$$\\frac{dP}{dz} = -\rho \cdot g$$

Where:
*   $P$ is atmospheric pressure.
*   $z$ is vertical altitude.
*   $\rho$ is air density (calculated via the ideal gas law: $\rho = \frac{P}{R_d T}$).
*   $g$ is gravitational acceleration.

### 2. CORIOLIS FORCE & GEOSTROPHIC WIND BALANCES
Above the planetary boundary layer, the wind vector ($V_g$) is modeled as a perfect balance between the horizontal Pressure Gradient Force and the Coriolis Force:

$$f \cdot v_g = \frac{1}{\rho} \frac{\partial P}{\partial x}$$
$$-f \cdot u_g = \frac{1}{\rho} \frac{\partial P}{\partial y}$$

Where:
*   $u_g, v_g$ are the zonal (east-west) and meridional (north-south) geostrophic wind components.
*   $f = 2\Omega \sin\phi$ is the Coriolis parameter ($\Omega$ is Earth's rotation rate, $\phi$ is latitude).

### 3. NUMERICAL WEATHER PREDICTION (NWP) MATRIX
To compile dynamic, high-precision local forecasts, the *Research Swarm* aggregates real-time data feeds (radar, satellite, weather balloons) and runs convective cloud models:

$$\text{Precipitation Probability (PoP)} = C \times A$$

Where:
*   $C$ is the statistical confidence that precipitation will form in the area.
*   $A$ is the fractional area that will receive measurable precipitation if it forms.
"""
        }
    }

    for path, data in meteorology_data.items():
        os.makedirs(path, exist_ok=True)
        file_path = os.path.join(path, data["file"])
        with open(file_path, 'w') as f:
            f.write(data["content"])
        print(f"  ✔ Created: {file_path}")

    print("\n" + "=" * 80)
    print("✔ Meteorology & Weather Forecasting Knowledge Slab written and integrated!")
    print("=" * 80)

if __name__ == "__main__":
    initialize_meteorology_science()
