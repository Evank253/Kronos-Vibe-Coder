# -*- coding: utf-8 -*-
import os
import json
import hashlib
import argparse

from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization

class KCNIndependentVerifier:
    """
    KCN-AKIIS Independent Audit Verifier (Layer 12).
    Verifies SHA-256 integrity digests and validates ECDSA cryptographic signatures
    against the auditor's public key (proving absolute, untampered authenticity).
    """
    def __init__(self):
        self.report_path = "KCN_BLACKBOX_AUDITOR/output/audit_report.json"
        self.metadata_path = "KCN_BLACKBOX_AUDITOR/output/signed_metadata.json"
        self.sig_path = "KCN_BLACKBOX_AUDITOR/output/audit_report.sig"
        self.public_key_path = "KCN_BLACKBOX_AUDITOR/integrity/auditor_public_key.pem"

    def calculate_file_sha256(self, filepath: str) -> str:
        """Computes the raw SHA-256 digest of a file."""
        if not os.path.exists(filepath):
            return "FILE_NOT_FOUND"
        sha256_hash = hashlib.sha256()
        with open(filepath, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    def verify_asymmetric_audit(self) -> bool:
        print("=" * 80)
        print(" KCN-AKIIS COGNITIVE INDEPENDENT CRYPTOGRAPHIC VERIFIER (v2.3)")
        print("=" * 80)

        # 1. Load and Validate Public Key Type (v2.3 Upgrade)
        print("[1/4] Loading and Validating Auditor Public Key...")
        if not os.path.exists(self.public_key_path):
            print(f"  [FAIL] Public key not found at '{self.public_key_path}'.")
            return False
            
        with open(self.public_key_path, "rb") as f:
            public_key = serialization.load_pem_public_key(f.read())
            
        # Explicitly validate elliptic curve key type to prevent algorithm ambiguity hacks
        if not isinstance(public_key, ec.EllipticCurvePublicKey):
            raise ValueError("KCN_CRYPT_ERR: Invalid key type. Auditor key must be a valid ECDSA elliptic curve public key.")
            
        print(f"  [PASS] Public Key loaded successfully & validated as ec.EllipticCurvePublicKey.")

        # 2. Recalculate and Verify SHA-256 Digest of the Report
        print("\n[2/4] Verifying SHA-256 Report Integrity...")
        if not os.path.exists(self.report_path):
            print(f"  [FAIL] Audit report not found at '{self.report_path}'.")
            return False
            
        calculated_hash = self.calculate_file_sha256(self.report_path)
        
        if not os.path.exists(self.metadata_path):
            print(f"  [FAIL] Signed metadata file not found at '{self.metadata_path}'.")
            return False
            
        with open(self.metadata_path, "r") as f:
            metadata_object = json.load(f)
            
        recorded_hash = metadata_object["sha256"]
            
        print(f"  ├── Recalculated Hash: 0x{calculated_hash}")
        print(f"  ├── Recorded Hash:     0x{recorded_hash}")
        
        if calculated_hash != recorded_hash:
            print("  [FAIL] SHA-256 report integrity mismatch!")
            return False
        print("  [PASS] SHA-256 REPORT INTEGRITY: MATCH & UN-TAMPERED.")

        # 3. Recalculate Raw Digest of the Metadata Object (v2.3 Upgrade)
        print("\n[3/4] Recalculating Signed Metadata Digest Bytes...")
        metadata_serialized = json.dumps(metadata_object, sort_keys=True)
        metadata_hash = hashlib.sha256(metadata_serialized.encode('utf-8')).hexdigest()
        metadata_hash_bytes = bytes.fromhex(metadata_hash)
        print(f"  [PASS] Metadata serialized canonical hash bytes generated successfully.")

        # 4. Verify ECDSA Cryptographic Signature over Raw Digest Bytes (v2.3 Upgrade)
        print("\n[4/4] Validating ECDSA Cryptographic Signature...")
        if not os.path.exists(self.sig_path):
            print(f"  [FAIL] Cryptographic signature file not found at '{self.sig_path}'.")
            return False
            
        with open(self.sig_path, "r") as f:
            sig_hex = f.read().strip()
            
        signature = bytes.fromhex(sig_hex)
        print(f"  ├── Loading Signature: 0x{sig_hex[:20]}...")
        
        try:
            # Verify the signature over the raw digest bytes (NIST P-256)
            public_key.verify(
                signature,
                metadata_hash_bytes,
                ec.ECDSA(hashes.SHA256())
            )
            print("  [PASS] ECDSA CRYPTOGRAPHIC SIGNATURE: VALID & GENUINE.")
        except Exception as e:
            print(f"  [FAIL] Invalid signature! {str(e)}")
            return False

        print("\n" + "=" * 80)
        print("                 CRYPTOGRAPHIC LEDGER VERIFICATION SUCCESSFUL")
        print("=" * 80)
        print("  [PASS] SHA-256 INTEGRITY: MATCH")
        print("  [PASS] ECDSA SIGNATURE:   VALID")
        print("  [PASS] AUDIT PACKAGE:     AUTHENTIC & COMMITTED")
        print("=" * 80)
        return True

if __name__ == "__main__":
    verifier = KCNIndependentVerifier()
    verifier.verify_asymmetric_audit()
