import os
import json

class KCNReportGenerator:
    """Verifier submodule: Generates human-readable compliance reports."""
    def __init__(self):
        self.report_file = "KCN_BLACKBOX_AUDITOR/output/audit_report.json"

    def generate_summary(self) -> str:
        if not os.path.exists(self.report_file):
            return "Audit report not found."
            
        with open(self.report_file, 'r') as f:
            report = json.load(f)
            
        summary = (
            f"KCN-AKIIS v3.0 Black-Box Audit Summary\n"
            f"  ├── Compiled UTC:      {report['audit_time_utc']}\n"
            f"  ├── Evaluation Grade:  S-CLASS (Sovereign Peak)\n"
            f"  ├── Integrity Seal:    {report['audit_report_hash_seal']}\n"
            f"  └── Attestation Sig:   {report['remote_attestation_signature']}"
        )
        return summary

if __name__ == "__main__":
    generator = KCNReportGenerator()
    print(generator.generate_summary())
