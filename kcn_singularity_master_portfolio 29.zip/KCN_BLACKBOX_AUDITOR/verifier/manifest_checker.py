import os
import json

class KCNManifestChecker:
    """Verifier submodule: Verifies manifest parameters and averages."""
    def __init__(self):
        self.manifest_file = "KCN_BLACKBOX_AUDITOR/input_sealed/benchmark_manifest.json"

    def run_manifest_check(self) -> bool:
        if not os.path.exists(self.manifest_file):
            print("[-] Manifest file missing!")
            return False
            
        print("[VERIFIER] Verifying benchmark manifest parameters...")
        with open(self.manifest_file, 'r') as f:
            manifest = json.load(f)
            
        # Verify total categories match
        assert len(manifest["evaluated_categories"]) == 12, "Evaluated categories count mismatch."
        assert manifest["provenance"]["task_seed"] == 472918, "Task seed parameters mismatch."
        
        print(f"  ✔ Manifest verified: Version {manifest['benchmark_standard_version']} and seed {manifest['provenance']['task_seed']} are valid.")
        return True

if __name__ == "__main__":
    checker = KCNManifestChecker()
    checker.run_manifest_check()
