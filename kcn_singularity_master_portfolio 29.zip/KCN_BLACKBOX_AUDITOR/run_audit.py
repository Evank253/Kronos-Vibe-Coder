# -*- coding: utf-8 -*-
import os
import json
import hashlib
from datetime import datetime

from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization

# Define sealed files to check
FILES = [
    "KCN_BLACKBOX_AUDITOR/input_sealed/benchmark_manifest.json",
    "KCN_BLACKBOX_AUDITOR/input_sealed/task_hashes.sha256",
    "KCN_BLACKBOX_AUDITOR/input_sealed/benchmark_telemetry_evidence.json",
    "KCN_BLACKBOX_AUDITOR/input_sealed/global_full_board_execution_results.json"
]

def sha256_file(path: str) -> str:
    """Computes the SHA-256 cryptographic digest of a file."""
    if not os.path.exists(path):
        return "FILE_NOT_FOUND"
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            h.update(chunk)
    return h.hexdigest()

def execute_asymmetric_blackbox_audit():
    print("=" * 80)
    print(" KCN ASYMMETRIC BLACK-BOX AUDITOR ENGINE - CORE RUNTIME (v2.3)")
    print("=" * 80)
    
    # Ensure output and integrity directories exist
    os.makedirs("KCN_BLACKBOX_AUDITOR/output", exist_ok=True)
    os.makedirs("KCN_BLACKBOX_AUDITOR/integrity", exist_ok=True)

    # 1. Generate or Load NIST P-256 ECDSA Keys
    private_key_path = "KCN_BLACKBOX_AUDITOR/integrity/auditor_private_key.pem"
    public_key_path = "KCN_BLACKBOX_AUDITOR/integrity/auditor_public_key.pem"
    
    if not os.path.exists(private_key_path):
        print("[KEYGEN] Generating fresh NIST P-256 ECDSA Keypair for Aethelgard Auditor...")
        private_key = ec.generate_private_key(ec.SECP256R1())
        public_key = private_key.public_key()
        
        # Save Private Key
        with open(private_key_path, "wb") as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            ))
            
        # Save Public Key
        with open(public_key_path, "wb") as f:
            f.write(public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ))
    else:
        print("[KEY_LOAD] Loading pre-existing Aethelgard Auditor keypair...")
        with open(private_key_path, "rb") as f:
            private_key = serialization.load_pem_private_key(f.read(), password=None)
        with open(public_key_path, "rb") as f:
            public_key = serialization.load_pem_public_key(f.read())

    # 2. Hash and Audit Sealed Inputs
    results = {
        "audit_time_utc": str(datetime.utcnow()),
        "auditor_standard": "KCN-BlackBox-Auditor-v4 (Asymmetric-ECDSA)",
        "files_audit": {}
    }

    for file in FILES:
        basename = os.path.basename(file)
        if os.path.exists(file):
            file_hash = sha256_file(file)
            print(f"  [PASS] Hashed: '{basename}' -> 0x{file_hash[:20]}... [FOUND]")
            results["files_audit"][basename] = {
                "sha256": file_hash,
                "status": "FOUND_AND_VERIFIED"
            }
        else:
            print(f"  [FAIL] Missing: '{basename}' [FAILED]")
            results["files_audit"][basename] = {
                "status": "MISSING"
            }

    # 3. Serialize and Write the JSON Audit Report
    output_path = "KCN_BLACKBOX_AUDITOR/output/audit_report.json"
    with open(output_path, "w") as f:
        json.dump(results, f, indent=2)

    # 4. Generate SHA-256 Digest of the Audit Report
    report_hash = sha256_file(output_path)
    hash_path = "KCN_BLACKBOX_AUDITOR/output/audit_report.sha256"
    with open(hash_path, "w") as f:
        f.write(report_hash)

    # 5. Build Canonicalized Signed Metadata Object (v2.3 Upgrade)
    metadata_object = {
        "artifact": "audit_report.json",
        "sha256": report_hash,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "version": "KCN-AKIIS-v2.3",
        "auditor": "Aethelgard_Sovereign_Auditor"
    }
    
    metadata_path = "KCN_BLACKBOX_AUDITOR/output/signed_metadata.json"
    with open(metadata_path, "w") as f:
        json.dump(metadata_object, f, indent=2, sort_keys=True)
        
    # Recalculate raw digest of the metadata object
    metadata_serialized = json.dumps(metadata_object, sort_keys=True)
    metadata_hash = hashlib.sha256(metadata_serialized.encode('utf-8')).hexdigest()
    metadata_hash_bytes = bytes.fromhex(metadata_hash)

    # 6. Sign the Raw Digest Bytes using ECDSA (NIST P-256)
    print("\n[SIGNER] Signing signed_metadata.json raw digest bytes using Private Key...")
    signature = private_key.sign(
        metadata_hash_bytes,
        ec.ECDSA(hashes.SHA256())
    )
    
    sig_hex = signature.hex()
    sig_path = "KCN_BLACKBOX_AUDITOR/output/audit_report.sig"
    with open(sig_path, "w") as f:
        f.write(sig_hex)

    # 7. Save final report signature inside integrity/ to seal the audit
    integrity_path = "KCN_BLACKBOX_AUDITOR/integrity/final_hash.sha256"
    with open(integrity_path, "w") as f:
        f.write(f"SHA256_DIGEST: {report_hash}\nECDSA_SIGNATURE: 0x{sig_hex}\n")

    print("\n" + "=" * 80)
    print("                      BLACK-BOX AUDIT COMPILATION COMPLETE")
    print("=" * 80)
    print(f"  Calculated Report Seal:        0x{report_hash[:20]}...")
    print(f"  ECDSA Cryptographic Signature: 0x{sig_hex[:20]}...")
    print(f"  Public Key Location:           '{public_key_path}'")
    print("=" * 80)
    print(f"✔ Audit report hash saved to: '{hash_path}'.")
    print(f"✔ Signed metadata object saved to: '{metadata_path}'.")
    print(f"✔ ECDSA Cryptographic signature saved to: '{sig_path}'.")
    print(f"✔ Final audit integrity seal written: '{integrity_path}'.")
    print("=" * 80)

if __name__ == "__main__":
    execute_asymmetric_blackbox_audit()
