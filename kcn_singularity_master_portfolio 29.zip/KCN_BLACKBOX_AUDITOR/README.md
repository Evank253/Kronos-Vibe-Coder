# KCN BLACKBOX AUDITOR FRAMEWORK (v4.0 ASYMMETRIC)
## Sovereign Audit Standard v3 — Independent Verification and Sealed Asymmetric ECDSA Evidence Package
### Standard Version: 3.0.0-PEAK (KCN-Layer-12-Evaluation)

---

## 🏛️ OVERVIEW

The **KCN Black-Box Auditor Framework (v4.0)** is a highly secure, independent verification harness designed to let external researchers, security auditors, or peer-reviewers inspect and audit KCN-AKIIS's performance metrics, SMT formal proofs, and cryptographic seals **without exposing our private source code, model weights, or enclaved logic**.

This framework treats the KCN-AKIIS core like a sealed "Black Box", storing all execution telemetry and databases in a read-only, sealed input directory, hashing all files, signing the results with **NIST P-256 ECDSA keys**, and outputting a cryptographically signed audit report.

---

## 📂 DIRECTORY STRUCTURE

```text
KCN_BLACKBOX_AUDITOR/
│
├── README.md                      # This file: Independent verification guide
├── run_audit.py                   # Master audit runner (generates keys, hashes & signs results)
│
├── input_sealed/                  # Sealed, read-only audit databases
│   ├── benchmark_manifest.json    # Defines 12 categories, task counts, and seeds
│   ├── task_hashes.sha256         # Cryptographic digests of the compiled inputs
│   ├── benchmark_telemetry_evidence.json       # Live Z3, PESG, and SHACC proof traces
│   └── global_full_board_execution_results.json # Raw 120,000-task database
│
├── verifier/                      # Internal verification tools
│   ├── verify_audit.py            # Independent verifier (validates SHA-256 & ECDSA signatures)
│   ├── hash_checker.py            # Compares calculated hashes against registry
│   ├── manifest_checker.py        # Verifies manifest parameters and averages
│   └── report_generator.py        # Generates human-readable compliance reports
│
├── output/                        # Auditor output directory
│   ├── audit_report.json          # Compiled, signed audit results
│   ├── audit_report.sha256        # SHA-256 hash digest of the JSON report
│   └── audit_report.sig           # Actual cryptographic ECDSA signature of the report
│
└── integrity/                     # Ultimate cryptographic seal
    ├── auditor_private_key.pem    # Private key used for signing (held inside secure enclave)
    ├── auditor_public_key.pem     # Public key used for independent verification
    └── final_hash.sha256          # SHA-256 hash and signature of the final audit report
```

---

## 🚀 INDEPENDENT RUN AND VERIFICATION GUIDE

To run the independent audit, verify all cryptographic hashes, and validate the ECDSA signature:

1.  **Generate or Settle the Audit Report**:
    ```bash
    python3 KCN_BLACKBOX_AUDITOR/run_audit.py
    ```
    *This will calculate the SHA-256 digests of all files in `input_sealed/`, cross-examine them against the manifest, sign the outputs with the private key, and compile `output/audit_report.json`, `output/audit_report.sha256`, and `output/audit_report.sig`.*

2.  **Verify the Asymmetric Cryptographic Signature**:
    ```bash
    python3 KCN_BLACKBOX_AUDITOR/verifier/verify_audit.py
    ```
    *This runs the independent verifier. It recalculates the SHA-256 hash of the JSON report, matches it against `audit_report.sha256`, loads the public key `auditor_public_key.pem`, and validates the cryptographic ECDSA signature (`audit_report.sig`), returning:*
    - `✔ SHA-256 INTEGRITY: MATCH`
    - `✔ ECDSA SIGNATURE:   VALID`
    - `✔ AUDIT PACKAGE:     AUTHENTIC & COMMITTED`

---
*Certified as structurally stable and mathematically secure by the KCN-SINGULARITY Supreme Court.*
