# Task: Generate and sum 10 million random integers
import random
import time

start_time = time.time()
numbers = [random.randint(1, 100) for _ in range(10_000_000)]
total_sum = sum(numbers)
end_time = time.time()

print(f"Sum: {total_sum}")
print(f"Execution Time: {end_time - start_time:.4f} seconds")
