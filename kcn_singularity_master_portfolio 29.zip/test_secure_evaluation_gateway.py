import json
import hashlib
from services.zero_knowledge_diagnoser import execute_secure_evaluation

def run_secure_evaluation_gateway_tests():
    print("=" * 80)
    print(" KCN-AKIIS SECURE API EVALUATION GATEWAY - SYSTEMS INTEGRITY CHECK")
    print("=" * 80)

    # --- TEST 1: GENERATING CRYPTOGRAPHIC EVALUATION RECEIPTS ---
    print("[1/2] Simulating public evaluator sending a prompt through the secure door...")
    prompt = "Verify bounds-checking on the hospital scheduler."
    nonce = "nonce_evaluator_test_472918"
    
    receipt = execute_secure_evaluation(prompt, nonce, "4-bit")
    print(f"  Receipt ID:              {receipt.receipt_id}")
    print(f"  Client Nonce Checked:    {receipt.client_nonce}")
    print(f"  Anonymous Output:        {receipt.anonymous_output_summary}")
    print(f"  SHA-256 Integrity Seal:  {receipt.sha256_integrity_seal}")
    print(f"  Remote Attestation Sig:  {receipt.remote_attestation_signature}")
    print(f"  Enclave Status:          {receipt.system_status}")
    
    # Assertions
    assert receipt.client_nonce == nonce, "Client nonce mismatch."
    assert "0x" in receipt.sha256_integrity_seal, "Integrity seal was not generated."
    assert "0x" in receipt.remote_attestation_signature, "Remote attestation signature was not generated."
    assert receipt.system_status == "ENCLAVE_ACTIVE_SECURE", "Should verify enclave state as secure."
    print("  ✔ SECURE API GATEWAY TRANSACTION: SOUND & CRYPTOGRAPHICALLY SECURED.\n")

    # --- TEST 2: REPLAY PREVENTION CHECK ---
    print("[2/2] Verifying that mutating the nonce changes the attestation signature...")
    receipt_mutated = execute_secure_evaluation(prompt, "nonce_mutated_991823", "4-bit")
    print(f"  Original Attestation: {receipt.remote_attestation_signature}")
    print(f"  Mutated Attestation:  {receipt_mutated.remote_attestation_signature}")
    
    assert receipt.remote_attestation_signature != receipt_mutated.remote_attestation_signature, "Attestation must depend on the single-use nonce."
    print("\n  ✔ REPLAY PROTECTION NONCE TRACKING: PERFECT.")
    print("-" * 80)
    print("✔ Secure API Evaluation Gateway tested successfully with 100% success!")
    print("=" * 80)

if __name__ == "__main__":
    run_secure_evaluation_gateway_tests()
