// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title x402EconomyToken
 * @dev ERC-20 Utility and Resource Billing Token for the KCN-AKIIS Sovereign Agent Economy.
 * Enforces anti-spam gas billing and micro-payments between autonomous agent nodes.
 */
contract x402EconomyToken {
    string public constant name = "KCN x402 Utility Token";
    string public constant symbol = "x402";
    uint8 public constant decimals = 18;
    uint256 public totalSupply;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    address public immutable systemGovernor;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    event GasBilled(address indexed agent, uint256 amount, string reason);

    modifier onlyGovernor() {
        require(msg.sender == systemGovernor, "KCN_ERR: UNAUTHORIZED_GOVERNOR_ONLY");
        _;
    }

    constructor(uint256 initialSupply) {
        systemGovernor = msg.sender;
        totalSupply = initialSupply * 10**uint256(decimals);
        balanceOf[msg.sender] = totalSupply;
        emit Transfer(address(0), msg.sender, totalSupply);
    }

    function transfer(address to, uint256 value) public returns (bool success) {
        require(balanceOf[msg.sender] >= value, "KCN_ERR: INSUFFICIENT_BALANCE");
        balanceOf[msg.sender] -= value;
        balanceOf[to] += value;
        emit Transfer(msg.sender, to, value);
        return true;
    }

    function approve(address spender, uint256 value) public returns (bool success) {
        allowance[msg.sender][spender] = value;
        emit Approval(msg.sender, spender, value);
        return true;
    }

    function transferFrom(address from, address to, uint256 value) public returns (bool success) {
        require(balanceOf[from] >= value, "KCN_ERR: INSUFFICIENT_BALANCE");
        require(allowance[from][msg.sender] >= value, "KCN_ERR: INSUFFICIENT_ALLOWANCE");
        balanceOf[from] -= value;
        balanceOf[to] += value;
        allowance[from][msg.sender] -= value;
        emit Transfer(from, to, value);
        return true;
    }

    /**
     * @dev Autonomously bills gas from an agent wallet for platform resource consumption.
     */
    function billGas(address agent, uint256 value, string memory reason) public onlyGovernor returns (bool success) {
        require(balanceOf[agent] >= value, "KCN_ERR: INSUFFICIENT_GAS_BALANCE");
        balanceOf[agent] -= value;
        balanceOf[systemGovernor] += value;
        emit GasBilled(agent, value, reason);
        emit Transfer(agent, systemGovernor, value);
        return true;
    }
}
