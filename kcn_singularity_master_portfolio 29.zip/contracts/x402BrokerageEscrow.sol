// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function transferFrom(address from, address to, uint256 value) external returns (bool);
    function transfer(address to, uint256 value) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
}

/**
 * @title x402BrokerageEscrow
 * @dev Autonomous Matching, Escrow, and Commission Splitter for the KCN-AKIIS Brokerage Engine.
 * Enforces an automated 10% platform commission fee for high-assurance matchmaking.
 */
contract x402BrokerageEscrow {
    address public immutable systemGovernor;
    address public immutable x402TokenAddress;
    uint256 public brokerageFeePercent = 10; // Deployed at 10% commission cut based on value-metric evaluation

    struct MatchmakingJob {
        address client;
        address serviceProvider;
        uint256 totalBudget;
        bool isCompleted;
        bool exists;
    }

    mapping(string => MatchmakingJob) public activeMatches;

    event MatchRouted(string indexed task_id, address indexed client, address indexed provider, uint256 budget);
    event MatchSettled(string indexed task_id, uint256 providerPayout, uint256 commissionFee);

    modifier onlyGovernor() {
        require(msg.sender == systemGovernor, "KCN_ERR: GOVERNOR_ACCESS_ONLY");
        _;
    }

    constructor(address _x402TokenAddress) {
        systemGovernor = msg.sender;
        x402TokenAddress = _x402TokenAddress;
    }

    /**
     * @dev Sets a new brokerage fee percentage (Governor/Owner only).
     */
    function setBrokerageFee(uint256 newFeePercent) public onlyGovernor {
        require(newFeePercent <= 25, "KCN_ERR: FEE_TOO_HIGH_MAX_25");
        brokerageFeePercent = newFeePercent;
    }

    /**
     * @dev Routes a verified match and locks the client's budget in escrow.
     */
    function routeMatch(
        string memory task_id,
        address client,
        address serviceProvider,
        uint256 budget
    ) public onlyGovernor returns (bool) {
        require(!activeMatches[task_id].exists, "KCN_ERR: MATCH_ALREADY_EXISTS");

        IERC20 token = IERC20(x402TokenAddress);
        bool success = token.transferFrom(client, address(this), budget);
        require(success, "KCN_ERR: CLIENT_ESCROW_TRANSFER_FAILED");

        activeMatches[task_id] = MatchmakingJob({
            client: client,
            serviceProvider: serviceProvider,
            totalBudget: budget,
            isCompleted: false,
            exists: true
        });

        emit MatchRouted(task_id, client, serviceProvider, budget);
        return true;
    }

    /**
     * @dev Settles the contract payout, splits the 10% commission cut, and forwards 90% to the provider.
     */
    function settleMatch(string memory task_id) public onlyGovernor returns (bool) {
        MatchmakingJob storage job = activeMatches[task_id];
        require(job.exists, "KCN_ERR: MATCH_NOT_FOUND");
        require(!job.isCompleted, "KCN_ERR: MATCH_ALREADY_SETTLED");

        IERC20 token = IERC20(x402TokenAddress);

        // Calculate the splits (10% commission, 90% provider payout)
        uint256 commissionFee = (job.totalBudget * brokerageFeePercent) / 100;
        uint256 providerPayout = job.totalBudget - commissionFee;

        job.isCompleted = true;

        // 1. Transfer 10% brokerage commission to the System Governor/Owner
        bool successGov = token.transfer(systemGovernor, commissionFee);
        require(successGov, "KCN_ERR: COMMISSION_TRANSFER_FAILED");

        // 2. Transfer the remaining 90% to the Service Provider agent
        bool successProv = token.transfer(job.serviceProvider, providerPayout);
        require(successProv, "KCN_ERR: PROVIDER_PAYOUT_FAILED");

        emit MatchSettled(task_id, providerPayout, commissionFee);
        return true;
    }
}
