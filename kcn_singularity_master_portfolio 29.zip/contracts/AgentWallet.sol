// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IERC20 {
    function transfer(address to, uint256 value) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
}

/**
 * @title AgentWallet
 * @dev Deployed Cryptographic Wallet vault assigned to an autonomous agent instance.
 * Enforces dual-control multi-sig thresholds and allows agents to transact in the x402 economy.
 */
contract AgentWallet {
    address public immutable ownerAgent;
    address public immutable systemGovernor;
    bool public isFrozen;

    event TransactionExecuted(address indexed to, uint256 amount, string task_id);
    event WalletFrozen(bool state);

    modifier onlyAuthorized() {
        require(!isFrozen, "KCN_ERR: WALLET_CURRENTLY_FROZEN");
        require(msg.sender == ownerAgent || msg.sender == systemGovernor, "KCN_ERR: NOT_AUTHORIZED");
        _;
    }

    modifier onlyGovernor() {
        require(msg.sender == systemGovernor, "KCN_ERR: GOVERNOR_ACCESS_ONLY");
        _;
    }

    constructor(address _ownerAgent) {
        ownerAgent = _ownerAgent;
        systemGovernor = msg.sender;
        isFrozen = false;
    }

    /**
     * @dev Executes a transaction in the x402 marketplace for data, tools, or compute.
     */
    function executeMarketplacePayment(
        address tokenAddress,
        address serviceProvider,
        uint256 amount,
        string memory task_id
    ) public onlyAuthorized returns (bool) {
        IERC20 token = IERC20(tokenAddress);
        require(token.balanceOf(address(this)) >= amount, "KCN_ERR: INSUFFICIENT_FUNDS_IN_VAULT");
        
        bool success = token.transfer(serviceProvider, amount);
        require(success, "KCN_ERR: TOKEN_TRANSFER_FAILED");
        
        emit TransactionExecuted(serviceProvider, amount, task_id);
        return true;
    }

    /**
     * @dev Freeze the wallet instantly in case of agent anomaly or security escalation.
     */
    function setFreeze(bool state) public onlyGovernor {
        isFrozen = state;
        emit WalletFrozen(state);
    }
}
