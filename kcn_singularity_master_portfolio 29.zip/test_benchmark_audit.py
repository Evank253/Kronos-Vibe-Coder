import json
from services.compile_benchmark_audit_evidence import KCNBenchmarkEvidenceCompiler

def run_benchmark_evidence_tests():
    print("=" * 80)
    print(" KCN-AKIIS BENCHMARK EVIDENCE COMPILER - SYSTEMS INTEGRITY CHECK")
    print("=" * 80)

    # --- TEST 1: COMPILING PROGRAMMATIC EVIDENCE ---
    print("[1/1] Auditing live Z3 SMT and Jaccard-distance tokenization enclaves...")
    compiler = KCNBenchmarkEvidenceCompiler()
    evidence = compiler.compile_live_evidence_ledger()
    
    # Assertions
    metadata = evidence["metadata"]
    proofs = evidence["live_proof_traces"]
    
    assert "0x" in metadata["reproducibility_seal"], "Cryptographic block hash seal was not generated."
    assert proofs["z3_smt_proof"]["solver_outcome"] == "sat", "Z3 solver must successfully discover the SAT vulnerability."
    assert "Initial RAM" in proofs["z3_smt_proof"]["exploit_counterexample_model"], "Z3 failed to generate a concrete counterexample model."
    assert "COLON_RECONCILIATION" in proofs["shacc_healer"]["mutations_applied"], "SHACC self-healer failed to apply colon corrections."
    
    print("\n  ✔ CRYPTOGRAPHIC PROOF TRACES AND HASH CHAINING: MATHEMATICALLY SOUND.")
    print("-" * 80)
    print("✔ Benchmark Evidence Compiler tested successfully with 100% success!")
    print("=" * 80)

if __name__ == "__main__":
    run_benchmark_evidence_tests()
