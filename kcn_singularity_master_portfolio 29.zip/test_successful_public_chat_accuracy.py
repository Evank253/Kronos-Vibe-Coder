import json
from fastapi import HTTPException
from kcn_singularity_unified_system import public_chat_gateway, PublicQueryRequest, credit_allowance_database, subscription_database

def test_successful_public_chatbox_accuracy():
    print("=" * 80)
    print(" KCN-AKIIS CHATBOX DEMONSTRATION: REAL-TIME ACCURACY & CREDIT AUDITING")
    print("=" * 80)
    
    free_user_id = "public_free_user_01"
    prompt = "What is the thermodynamic efficiency limit of a silicon photovoltaic cell?"
    
    # 1. Ensure free user is registered in the credit database with 5 credits
    credit_allowance_database[free_user_id] = 5
    # Ensure they are NOT listed in the paid subscription database
    if free_user_id in subscription_database:
        del subscription_database[free_user_id]
        
    print(f"Initial State: '{free_user_id}' has {credit_allowance_database[free_user_id]} free credits.")
    
    # 2. RUN 1: Execute their first verified query (requires 3 credits)
    print(f"\n[RUN 1] User '{free_user_id}' submits: '{prompt}'")
    req1 = PublicQueryRequest(prompt=prompt, user_id=free_user_id)
    
    try:
        response1 = public_chat_gateway(req1)
        print("\n[SYSTEM RESPONSE (With Appended Accuracy & Verification Card)]:")
        print(response1["output_text"])
        print(f"Post-Run 1 State: Remaining Free Credits: {response1['metrics']['remaining_credits']}\n")
    except Exception as e:
        print(f"[-] Run 1 Error: {str(e)}")
        
    # 3. RUN 2: User attempts to execute a second verified query (requires 3 credits, but they only have 2 left)
    print("-" * 80)
    print(f"[RUN 2] User '{free_user_id}' attempts to submit second query (Cost: 3 credits, Balance: {credit_allowance_database[free_user_id]})...")
    req2 = PublicQueryRequest(prompt=prompt, user_id=free_user_id)
    
    try:
        public_chat_gateway(req2)
    except HTTPException as e:
        print("\n  ✔ KCN Billing Gateway successfully intercepted credit exhaustion!")
        print(f"    Gateway Response Code: {e.status_code} (Payment Required)")
        print(f"    Gateway Response Detail: {json.dumps(e.detail, indent=2)}")
    except Exception as e:
        print(f"[-] Run 2 Error: {str(e)}")
        
    print("=" * 80)

if __name__ == "__main__":
    test_successful_public_chatbox_accuracy()
