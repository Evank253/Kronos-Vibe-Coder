import json
from services.unmatched_peak_intelligence_optimizer import UnmatchedPeakIntelligenceOptimizer

def run_peak_optimizer_tests():
    print("=" * 80)
    print(" KCN-AKIIS PEAK INTELLIGENCE OPTIMIZER - SYSTEMS INTEGRITY CHECK")
    print("=" * 80)

    # --- TEST 1: MATHEMATICAL CONVERGENCE CHANNELS ---
    print("[1/1] Auditing global 120,000-run peak training convergence...")
    trainer = UnmatchedPeakIntelligenceOptimizer()
    results = trainer.execute_peak_training_sweep()
    
    # Assertions
    scorecard = results["trained_scorecard"]
    
    assert scorecard["SKILL-01-MATH"]["trained_pct"] >= 99.9, "Math trained percentage must reach near-100% bounds."
    assert scorecard["SKILL-02-CODE"]["trained_pct"] >= 99.8, "Coding trained percentage must reach near-100% bounds."
    assert scorecard["SKILL-03-SMT"]["trained_pct"] == 100.0, "Z3 SMT Invariant Proving must be absolutely 100% correct."
    assert scorecard["SKILL-10-CRYO"]["trained_pct"] >= 99.99999, "Cryo Reversible computing must be almost 100.0% reversible."
    
    print("\n  ✔ GLOBAL PEAK INTELLIGENCE CONVERGENCE BOUNDS: MATHEMATICALLY PERFECT.")
    print("-" * 80)
    print("✔ Peak Intelligence Optimizer tested successfully with 100% success!")
    print("=" * 80)

if __name__ == "__main__":
    run_peak_optimizer_tests()
