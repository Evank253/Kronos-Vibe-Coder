import json
from services.benchmark_compiler_swarm import generate_mutated_benchmark_vector

def run_benchmark_compiler_tests():
    print("=" * 80)
    print(" KCN-AKIIS ACTIVE BENCHMARK COMPILER - SYSTEMS INTEGRITY CHECK")
    print("=" * 80)

    # --- TEST 1: MATH PARAMETER SCRAMBLING ---
    print("[1/2] Attempting to scramble a static mathematics benchmark task...")
    task_id = "MATH-001"
    prompt = "Calculate compound interest for a $10,000 investment at 6% over 10 years."
    output = "$17,908.48"
    
    mut_prompt, mut_cond, mut_out, logs = generate_mutated_benchmark_vector(task_id, prompt, output)
    print(f"  Original Prompt: {prompt}")
    print(f"  Mutated Prompt:  {mut_prompt}")
    print(f"  Mutated Conditions: {mut_cond}")
    print(f"  Mutated Output:  {mut_out}")
    
    assert "$15,000" in mut_prompt, "Parameter scrambling failed to change investment size."
    assert "8%" in mut_prompt, "Parameter scrambling failed to change rate."
    print("  ✔ ACTIVE MATHEMATICS TEST MUTATION: STABLE & SUCCESSFUL.\n")

    # --- TEST 2: CODING AST SCRAMBLING ---
    print("[2/2] Attempting to scramble a static coding benchmark task...")
    task_id_code = "CODE-002"
    prompt_code = "Design a bounds-checked memory copy function."
    output_code = "dest_buffer copy complete."
    
    mut_prompt_c, mut_cond_c, mut_out_c, logs_c = generate_mutated_benchmark_vector(task_id_code, prompt_code, output_code)
    print(f"  Original Prompt: {prompt_code}")
    print(f"  Mutated Prompt:  {mut_prompt_c}")
    print(f"  Mutated Conditions: {mut_cond_c}")
    print(f"  Mutated Output:  {mut_out_c}")
    
    assert "512MB" in mut_prompt_c, "Boundary limit shift failed to modify limits."
    print("\n  ✔ ACTIVE CODING AST MUTATION: STABLE & SUCCESSFUL.")
    print("-" * 80)
    print("✔ Active Benchmark Compiler Swarm tested successfully with 100% success!")
    print("=" * 80)

if __name__ == "__main__":
    run_benchmark_compiler_tests()
