# KCN SOVEREIGN ECONOMICS KNOWLEDGE SLAB
## Category Index: 15_sovereign_economics
## Core Axioms: x402 Ledger, Agent Wallets, Smart Contracts, and Double-Billing Defenses

### 1. THE x402 PROGRAMMABLE LEDGER
The **x402 Economy Engine** operates on a private, high-speed, and append-only Hyperledger Fabric blockchain. All agent wallet balances, gas fees, and contract commissions are processed as secure smart contract executions.

### 2. AGENT WALLET STRUCTURE (contracts/AgentWallet.sol)
Each agent is assigned an independent wallet contract:
*   *Owner*: The physical agent address.
*   *Sponsor/Governor*: The platform governor address.
*   *Permissions*: The wallet can transfer funds to other agents for registered services, but cannot execute public transfers unless co-signed by the Governor.
*   *Freeze Trigger*: The governor can call `setFreeze(true)` at any time, instantly suspending the wallet.

### 3. DOUBLE-BILLING PROTECTION
To prevent double-billing attacks:
*   Every transaction request is assigned a unique, cryptographically signed `nonce`.
*   The ledger maintains an in-memory key-value database of processed nonces.
*   If a duplicate nonce is submitted, the transaction is instantly rejected as a fraud attempt.
