# KCN CIVIL ENGINEERING & CONSTRUCTION KNOWLEDGE SLAB
## Category Index: 03_engineering (Sub-Sector: Construction)
## Core Axioms: Structural Loading, Shear Force, Beam Deflection, and Material Tolerances

### 1. STRUCTURAL LOADING EQUATIONS
To ensure structural integrity in KCN-designed physical facilities, we calculate total dead load ($D$) and live load ($L$):

$$U = 1.2D + 1.6L$$

Where $U$ is the ultimate design load required under structural design codes (ACI 318).

### 2. BEAM DEFLECTION & ELASTICITY
We model the deflection ($\delta$) of a simply supported beam under a concentrated central load ($P$):

$$\delta_{	ext{max}} = rac{PL^3}{48EI}$$

Where:
*   $P$ is the applied central load.
*   $L$ is the length of the span.
*   $E$ is Modulus of Elasticity of the material.
*   $I$ is Area Moment of Inertia of the cross-section.

### 3. CONCRETE STRESS-STRAIN TENSORS
To model concrete reinforcement boundaries, we evaluate the compressive stress-strain profile using the Whitney stress block representation:

$$a = eta_1 \cdot c$$

Where:
*   $a$ is the depth of the equivalent rectangular stress block.
*   $c$ is the distance from the extreme compression fiber to the neutral axis.
*   $eta_1$ is a reduction factor ranging from 0.65 to 0.85 based on compressive strength ($f'_c$).
