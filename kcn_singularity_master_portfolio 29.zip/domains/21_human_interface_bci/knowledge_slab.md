# KCN HUMAN-AI INTERFACE KNOWLEDGE SLAB
## Category Index: 21_human_interface_bci
## Core Axioms: EEG/BCI Neural Telemetry, LSL Stream Formats, and Privacy Guard Boundaries

### 1. BCI NEURAL TELEMETRY
We support non-invasive brain-computer interface (BCI) telemetry, processing raw Electroencephalography (EEG) signals through a local Lab Streaming Layer (LSL) stream.

### 2. LSL STREAM DATA FORMAT
```json
{
  "stream_name": "OpenBCI_EEG",
  "channel_count": 8,
  "sampling_rate": 250.0,  // Hz
  "data_format": "float32"
}
```

### 3. COGNITIVE PRIVACY GUARDIAN RULES (Article V)
*   **Explicit Consent**: No neural signal is collected without a real-time cryptographic signature from the user's bound MetaMask wallet.
*   **Zero Storage Policy**: Raw brain-waves are processed exclusively in transient RAM, transformed into anonymous feature vectors, and immediately destroyed.
*   **Coercion Detection**: The BCI monitor scans neural channels for stress-coercion signatures, automatically blocking key-signing events if coercion is suspected.
