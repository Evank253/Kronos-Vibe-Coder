# KCN LANDSCAPING & SOIL ECOLOGY KNOWLEDGE SLAB
## Category Index: 38_landscaping_and_design
## Core Axioms: Hydrologic Runoff, Soil pH Chemistry, and Plant Microclimates

### 1. HYDROLOGIC RUNOFF LAW (THE RATIONAL METHOD)
To design efficient landscape drainage and grading systems, we calculate peak storm runoff rate ($Q$):

$$Q = C \cdot I \cdot A$$

Where:
*   $Q$ is peak runoff rate (in cubic feet per second).
*   $C$ is dimensionless runoff coefficient (ranging from 0.1 for sandy lawns to 0.9 for asphalt).
*   $I$ is rainfall intensity (inches per hour).
*   $A$ is drainage area (acres).

### 2. SOIL pH & NITROGEN-PHOSPHORUS-POTASSIUM (NPK) CHEMISTRY
The *Landscaping Agent* evaluates soil chemical profiles. Plant growth requires optimal pH ranges (typically 6.0 to 7.0) to facilitate nutrient uptake:

$$	ext{NPK Optimal Ratio (Lawn): } 4 : 1 : 2 \quad 	ext{NPK Optimal Ratio (Garden): } 1 : 2 : 1$$

### 3. MICROCLIMATE TEMPERATURE THERMAL LOOPS
We model physical temperature modulations caused by shade trees using the transpiration cooling equation:

$$\Delta T = rac{\lambda \cdot E_{	ext{trans}}}{C_p \cdot ho \cdot V}$$

Where:
*   $\lambda$ is latent heat of vaporization of water.
*   $E_{	ext{trans}}$ is tree water transpiration rate.
*   $C_p \cdot ho$ is volumetric heat capacity of air.
*   $V$ is localized wind volume.
