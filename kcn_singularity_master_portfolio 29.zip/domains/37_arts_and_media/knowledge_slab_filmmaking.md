# KCN FILMMAKING & THEATER KNOWLEDGE SLAB
## Category Index: 37_arts_and_media
## Core Axioms: Rule of Thirds, Three-Act Narrative Structures, and Lens Optics

### 1. CINEMATIC COMPOSITION & THE RULE OF THIRDS
For visual framing, the *Creative Agent* divides the camera viewport into a $3 	imes 3$ grid. Points of interest must lie at the intersections of the horizontal and vertical dividing lines:

$$x_{	ext{grid}} \in \left\{ rac{W}{3}, rac{2W}{3} ight\} \quad \land \quad y_{	ext{grid}} \in \left\{ rac{H}{3}, rac{2H}{3} ight\}$$

### 2. CAMERA LENS OPTICS & DEPTH OF FIELD
We model camera lens focal length ($f$) and aperture ($N$-stop) to calculate Depth of Field (DoF):

$$	ext{Hyperfocal Distance: } H = rac{f^2}{N \cdot c} + f$$

Where $c$ is the circle of confusion limit.

### 3. THREE-ACT THEATRICAL STRUCTURE
To write compelling narrative scripts, the *Creative Agent* structures plot pacing using the classical Aristotelian Three-Act template:
*   **Act I (Setup)**: 0% to 25% of timeline. Climax 1 occurs at the 25% point.
*   **Act II (Confrontation)**: 25% to 75% of timeline. Midpoint climax occurs at the 50% point.
*   **Act III (Resolution)**: 75% to 100% of timeline. Final climax occurs at the 90% point.
