# KCN CYBERSECURITY DEFENSE KNOWLEDGE SLAB
## Category Index: 11_cybersecurity_defense
## Core Axioms: gVisor Syscall Interception, mTLS handshakes, and Sandbox Containment

### 1. gVISOR SYSTEM CALL INTERCEPTION (SENTRY)
All execution sandboxes at Layer 6 run inside **gVisor**. The Sentry user-space kernel intercepts all system calls made by compiled WebAssembly programs.
*   **Allowed Syscalls**: `read()`, `write()`, `futex()`, `exit_group()`.
*   **Blocked/Filtered Syscalls**: `socket()`, `execve()`, `clone()`, `ptrace()`, `chmod()`. Any attempt to run a blocked syscall triggers an immediate container shutdown.

### 2. MUTUAL TLS (mTLS) NETWORK HANDSHAKES
To secure service-to-service communications, KCN enforces Istio-managed mTLS handshakes:
1.  Client connects to server port.
2.  Server presents its cryptographically signed X.509 certificate.
3.  Client presents its X.509 certificate.
4.  Both validate certificates against the **Keycloak/Vault root CA**.
5.  Symmetric session keys are generated via Ephemeral Diffie-Hellman (ECDHE-ECDSA-AES256-GCM-SHA384).

### 3. CONTAINMENT BREAKOUT PREVENTION
We assume container breakout attempts are always possible at the software level. Therefore, the physical host operates under a strict **air-gapped VPC segment**, ensuring that even a successful kernel breakout cannot exfiltrate packet data to the public internet.
