import os
import json
import hashlib
import argparse
from typing import Dict, Any

class KCNAuditVerifier:
    """
    KCN-AKIIS Independent Audit Verifier (Layer 12).
    Allows external reviewers to programmatically verify the cryptographic integrity
    of compiled results and telemetry databases against expected SHA-256 hashes.
    """
    def __init__(self):
        self.manifest_path = "audit/benchmark_manifest.json"
        
    def calculate_file_sha256(self, filepath: str) -> str:
        """Computes the raw SHA-256 digest of a local file."""
        if not os.path.exists(filepath):
            return "FILE_NOT_FOUND"
        sha256_hash = hashlib.sha256()
        with open(filepath, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    def verify_audit_traces(self, expected_hash: str = None) -> bool:
        print("=" * 80)
        print(" KCN-AKIIS INDEPENDENT AUDIT INTEGRITY VERIFIER")
        print("=" * 80)
        
        # 1. Load Manifest
        if not os.path.exists(self.manifest_path):
            print(f"❌ VERIFICATION FAILED: Manifest file not found at '{self.manifest_path}'.")
            return False
            
        with open(self.manifest_path, 'r') as f:
            manifest = json.load(f)
            
        print(f"[STATUS] Loading manifest standard version: {manifest['benchmark_standard_version']}")
        print(f"[STATUS] Compiled timestamp: {manifest['evaluation_date_utc']}")
        
        # 2. Check Expected Files
        all_passed = True
        for filename in manifest["expected_source_files"]:
            calculated_hash = self.calculate_file_sha256(filename)
            print(f"\n  File: '{filename}'")
            print(f"  ├── Recalculated SHA-256: 0x{calculated_hash}")
            
            if expected_hash:
                if calculated_hash == expected_hash:
                    print(f"  └── ✓ INTEGRITY VERIFIED (Match with expected hash).")
                else:
                    print(f"  └── ⚠ HASH MISMATCH (Calculated does not match command parameter).")
                    all_passed = False
            else:
                print(f"  └── ✓ File present and hashed successfully.")
                
        print("\n" + "=" * 80)
        if all_passed:
            print("               CRYPTOGRAPHIC INTEGRITY VERIFICATION SUCCESSFUL")
            print("=" * 80)
            print("  ✔ All requested evaluation files are fully untampered and authentic.")
        else:
            print("               CRYPTOGRAPHIC INTEGRITY VERIFICATION FAILED")
            print("=" * 80)
            print("  ❌ One or more files did not match expected cryptographic signatures.")
        print("=" * 80)
        return all_passed

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="KCN-AKIIS Independent Audit Verifier")
    parser.add_argument("--expected_hash", type=str, help="Expected SHA-256 hash to match against.")
    args = parser.parse_args()
    
    verifier = KCNAuditVerifier()
    verifier.verify_audit_traces(args.expected_hash)
