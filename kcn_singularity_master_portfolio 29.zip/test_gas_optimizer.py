import json
from services.gas_efficiency_optimizer import optimize_resource_gas

def run_gas_optimizer_tests():
    print("=" * 80)
    print(" KCN-AKIIS GAS EFFICIENCY OPTIMIZER - SYSTEMS INTEGRITY CHECK")
    print("=" * 80)

    # --- TEST 1: BLOCKCHAIN COMPRESSION & SCHNORR AGGREGATION ---
    print("[1/2] Simulating 3 raw blockchain transactions with Schnorr aggregation...")
    raw_txs = [
        {"tx_id": "tx_01", "gas": 150000},
        {"tx_id": "tx_02", "gas": 150000},
        {"tx_id": "tx_03", "gas": 150000}
    ]
    
    base, opt, savings, lifespan, token_red, logs = optimize_resource_gas(
        raw_txs,
        schnorr=True,
        plasma_recycle=True,
        cache_hits=4
    )
    
    print(f"  Base Gas Limit:      {base} gas")
    print(f"  Optimized Gas Limit: {opt} gas")
    print(f"  Gas Savings:         {savings}%")
    print(f"  Token Billing Red:   {token_red}%")
    
    # Assertions
    assert base == 450000, "Base gas for 3 transactions should be 450,000."
    assert opt < base, "Optimized gas must be significantly less than base gas."
    assert savings == 78.5, "Schnorr aggregation must achieve exactly 78.5% gas savings in our model."
    print("  ✔ BLOCKCHAIN GAS COMPRESSION & SCHNORR AGGREGATION: VERIFIED.\n")

    # --- TEST 2: REACTOR PLASMA FUEL RECYCLING ---
    print("[2/2] Verifying plasma fuel cell lifespan elongation...")
    print(f"  Unoptimized Lifespan: 30.0 days")
    print(f"  Optimized Lifespan:   {lifespan} days")
    
    assert lifespan == 135.0, "Reactor fuel lifespan with MHD recycling should be extended to 135.0 days."
    print("  ✔ FUSION PLASMA FUEL RECYCLING PATHWAYS: STABLE & SOUND.")
    print("-" * 80)
    print("✔ Gas Efficiency and Resource Optimizer tested successfully with 100% success!")
    print("=" * 80)

if __name__ == "__main__":
    run_gas_optimizer_tests()
