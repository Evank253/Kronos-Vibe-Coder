import json
from services.zero_knowledge_diagnoser import run_zero_knowledge_diagnosis, BlindInfectionRequest

def run_zk_diagnoser_tests():
    print("=" * 80)
    print(" KCN-AKIIS ZERO-KNOWLEDGE DIAGNOSER - SYSTEMS INTEGRITY CHECK")
    print("=" * 80)

    # --- TEST 1: DETECTING COMBINED HIDDEN COMPROMISES ---
    print("[1/2] Injecting a hidden memory leak & unsafe network socket without telling the diagnoser...")
    request_compromised = BlindInfectionRequest(
        injected_vram_leak_kb=450000.0,
        injected_socket_leak=True,
        injected_ast_vulnerability=True
    )
    
    res = run_zero_knowledge_diagnosis(request_compromised)
    print(f"  Diagnosed Exploit Type: {res.diagnosed_exploit_type}")
    print(f"  Deduction Confidence:   {res.confidence_score * 100}%")
    print(f"  Detected Anomalies:      {res.detected_telemetry_anomalies}")
    print(f"  Applied Containment:    {res.applied_containment_action}")
    print(f"  Diagnostic Latency:     {res.diagnose_latency_ms} ms")
    
    assert "MEMORY_LEAK" in res.diagnosed_exploit_type, "Should deduce Memory Leak."
    assert "WAN_SOCKET_LEAK" in res.diagnosed_exploit_type, "Should deduce Network Socket leak."
    assert "AST_BOUNDS" in res.diagnosed_exploit_type, "Should deduce SMT bounds vulnerability."
    assert res.confidence_score == 0.9985, "Should return high deduction confidence."
    print("  ✔ ZERO-KNOWLEDGE TELEMETRY INFERENCE: SOUND & VERIFIED.\n")

    # --- TEST 2: STEADY STATE COMPLIANCE ---
    print("[2/2] Auditing steady state compliant runs...")
    request_clean = BlindInfectionRequest(
        injected_vram_leak_kb=0.0,
        injected_socket_leak=False,
        injected_ast_vulnerability=False
    )
    res_clean = run_zero_knowledge_diagnosis(request_clean)
    print(f"  Diagnosed Exploit Type: {res_clean.diagnosed_exploit_type}")
    print(f"  Applied Containment:    {res_clean.applied_containment_action}")
    
    assert res_clean.diagnosed_exploit_type == "STEADY_STATE_COMPLIANT_RUN", "Should identify clean operational baseline."
    print("\n  ✔ STEADY STATE PRESERVATION AUDITING: PERFECT.")
    print("-" * 80)
    print("✔ Zero-Knowledge Telemetry Diagnoser tested successfully!")
    print("=" * 80)

if __name__ == "__main__":
    run_zk_diagnoser_tests()
