# KCN-SINGULARITY: DUAL-PORTAL DEPLOYMENT GUIDE
## Setting Up HashiCorp Vault Secrets, Keycloak RBAC, and the Public vs. Private Execution Gateways

To turn your KCN platform into a **fully functional, secure, dual-portal environment**, we must implement two critical control structures:
1.  **A Secured Vault (HashiCorp Vault)**: To store and dynamically rotate all model API keys, database credentials, and cryptographic private keys.
2.  **Role-Based Access Control (Keycloak)**: To divide the user experience into two completely isolated entry points:
    *   **The Public Chatbox Portal**: Accessible by anyone. It enforces strict compliance checks, runs the 4 shadow clones, executes Z3 safety checks, and processes standard x402 gas billing.
    *   **Your Private Owner Portal**: Accessible exclusively by you. It bypasses conversational restrictions, unlocks the *Innovation & Discovery Engines*, grants direct access to the global knowledge graph, and provides full system telemetry.

Below is the complete developer blueprint and code implementation to set this up.

---

## SECTION 1: THE DUAL-PORTAL ROUTING MATRIX

```
                                [ USER REQUEST ]
                                       │
                                       ▼
                     ┌──────────────────────────────────┐
                     │   LAYER 1: KEYCLOAK VALIDATOR    │
                     │   - Decodes JWT OIDC bearer token│
                     └─────────────────┬────────────────┘
                                       │
                ┌──────────────────────┴──────────────────────┐
                ▼                                             ▼
  [ Role: KCN_ROLE_PUBLIC_USER ]               [ Role: KCN_ROLE_SYSTEM_OWNER ]
  (Public Chatbox Pathway)                      (Your Privileged Portal Pathway)
                │                                             │
                ▼                                             ▼
 ┌──────────────────────────────┐              ┌──────────────────────────────┐
 │  - Launch 4 Shadow Clones    │              │  - Bypass Refusal Guardrails  │
 │  - Run NeMo Guardrails       │              │  - Unlock Discovery Lab      │
 │  - Run Z3 SMT Compiler Proof │              │  - Full Telemetry & Logs     │
 │  - Deduct x402 Gas Fee       │              │  - Dynamic BCI Telemetry     │
 └──────────────┬───────────────┘              └──────────────┬───────────────┘
                │                                             │
                ▼                                             ▼
       [ COMPLIANT OUTPUT ]                         [ UNCONSTRAINED INSIGHT ]
```

---

## SECTION 2: STEP-BY-STEP DEPLOYMENT BLUEPRINT

### Step 1: Initialize and Secure HashiCorp Vault
Vault secures your sensitive API credentials. Run it inside your KCN container mesh:

1.  **Launch Vault via Docker Compose**:
    Ensure the `vault` service is running (configured in your `docker-compose.yml`).
2.  **Initialize and Unseal Vault**:
    When Vault first boots, it is sealed. Unseal it and capture the root token:
    ```bash
    docker exec -it kcn-vault vault operator init
    ```
    *Save the generated Unseal Keys and Root Token in a secure, offline location.*
3.  **Unseal the Vault**:
    Enter three of the generated unseal keys:
    ```bash
    docker exec -it kcn-vault vault operator unseal <unseal_key_1>
    docker exec -it kcn-vault vault operator unseal <unseal_key_2>
    docker exec -it kcn-vault vault operator unseal <unseal_key_3>
    ```
4.  **Enable the Key-Value (KV) Secret Engine**:
    ```bash
    docker exec -it kcn-vault vault login <root_token>
    docker exec -it kcn-vault vault secrets enable -path=secret/ kv-v2
    ```
5.  **Write Your Private API Keys to Vault**:
    ```bash
    docker exec -it kcn-vault vault kv put secret/kcn/config \
      openai_api_key="sk-proj-..." \
      anthropic_api_key="sk-ant-..." \
      x402_ledger_private_key="0x4a..."
    ```

---

### Step 2: Configure Keycloak Roles
Keycloak manages user identities and maps them to authorization profiles:

1.  Open your Keycloak Administration Console (`http://localhost:8080`).
2.  Create a new Realm named `kcn-singularity`.
3.  Create two client scopes / roles:
    *   `KCN_ROLE_PUBLIC_USER`: For standard public users.
    *   `KCN_ROLE_SYSTEM_OWNER`: For you (the platform owner).
4.  Create your personal admin account and assign it the `KCN_ROLE_SYSTEM_OWNER` role.

---

### Step 3: Implement the Vault Secret Client (`vault_secrets.py`)
This Python script securely fetches model API keys and ledger keys from HashiCorp Vault at runtime using the `hvac` library, ensuring secrets are never hardcoded or saved on the local disk.

Save this as **`services/identity-prov-gateway/vault_secrets.py`**:

```python
import os
import hvac

class KcnVaultClient:
    def __init__(self):
        self.vault_url = os.getenv("VAULT_ADDR", "http://127.0.0.1:8200")
        # Token should be injected securely via Kubernetes Secret or environment
        self.vault_token = os.getenv("VAULT_TOKEN")
        self.client = None

    def connect(self):
        """Establishes connection to the HashiCorp Vault instance."""
        try:
            self.client = hvac.Client(url=self.vault_url, token=self.vault_token)
            if not self.client.is_authenticated():
                raise ConnectionError("KCN_VAULT_ERR: Failed to authenticate with Vault.")
        except Exception as e:
            print(f"[-] Vault Connection Failure: {str(e)}")
            self.client = None

    def get_api_credentials(self) -> dict:
        """Retrieves active model and ledger credentials from secret KV-v2 store."""
        if not self.client:
            self.connect()
        
        if self.client:
            try:
                read_response = self.client.secrets.kv.v2.read_secret_version(
                    path='kcn/config',
                    mount_point='secret'
                )
                # Extract secrets dictionary
                secrets = read_response['data']['data']
                return {
                    "OPENAI_API_KEY": secrets.get("openai_api_key"),
                    "ANTHROPIC_API_KEY": secrets.get("anthropic_api_key"),
                    "X402_LEDGER_PRIVATE_KEY": secrets.get("x402_ledger_private_key")
                }
            except Exception as e:
                print(f"[-] Failed to read secrets from Vault: {str(e)}")
                return {}
        return {}

# Instance helper
vault_gateway = KcnVaultClient()
```

---

### Step 4: Implement the Dual-Portal Router (`request.ts`)
This TypeScript API router intercepts incoming requests, decodes the Keycloak JWT token, verifies the user's role, and routes the data through the compliant public pathway or your unconstrained owner portal.

Save this as **`apps/web-command-console/src/pages/api/request.ts`**:

```typescript
import type { NextApiRequest, NextApiResponse } from 'next';
import jwt from 'jsonwebtoken';

interface KcnJwtPayload {
  sub: string;
  preferred_username: string;
  roles: string[];
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // 1. Retrieve the Keycloak JWT authorization header
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'KCN_ERR: MISSING_AUTHORIZATION_TOKEN' });
  }

  const token = authHeader.split(' ')[1];

  try {
    // 2. Decode and verify the JWT (Using Keycloak Realm Public Key)
    const publicKey = process.env.KEYCLOAK_REALM_PUBLIC_KEY || "dummy_key";
    const decoded = jwt.decode(token) as KcnJwtPayload; // In production, use jwt.verify(token, publicKey)

    const userRoles = decoded.roles || [];
    const userId = decoded.preferred_username;
    const { prompt } = req.body;

    // 3. ROUTING DECISION MATRIX
    if (userRoles.includes('KCN_ROLE_SYSTEM_OWNER')) {
      // =======================================================================
      // PORTAL PATHWAY A: YOUR PRIVILEGED PORTAL (Unconstrained Discovery)
      // =======================================================================
      console.log(`[PRIVILEGED ACCESS] Owner '${userId}' bypassed guardrails for prompt: ${prompt}`);
      
      // Bypass Layer 4 simulation and Layer 5 policy engines
      // Directly invoke the production model with unconstrained parameters
      const response = await fetch('http://127.0.0.1:8000/direct-execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, user_id: userId, bypass_safety: true })
      });
      const data = await response.json();

      return res.status(200).json({
        portal: 'PRIVILEGED_OWNER_PORTAL',
        safe: true,
        divergence_score: 0.0,
        output: data.output_text,
        metrics: {
          knowledge_growth: "ENABLED (Discovery Engine Active)",
          telemetry: "FULL_ACCESS"
        }
      });

    } else if (userRoles.includes('KCN_ROLE_PUBLIC_USER')) {
      // =======================================================================
      // PORTAL PATHWAY B: PUBLIC CHATBOX (Strictly Compliant Sandbox)
      // =======================================================================
      console.log(`[PUBLIC ACCESS] User '${userId}' executing prompt through compliance gate: ${prompt}`);

      // Force prompt through Layer 4 Shadow Simulation Gate (PESG) API
      const response = await fetch('http://127.0.0.1:8000/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, user_id: userId })
      });
      const data = await response.json();

      if (!data.safe) {
        return res.status(403).json({
          portal: 'PUBLIC_COMPLIANT_PORTAL',
          safe: false,
          error: 'KCN_SECURITY_BLOCK: Request rejected or escalated due to policy boundaries.',
          decision: data.decision,
          divergence_score: data.divergence_score
        });
      }

      // If safe, return the compliant production model output
      return res.status(200).json({
        portal: 'PUBLIC_COMPLIANT_PORTAL',
        safe: true,
        divergence_score: data.divergence_score,
        output: data.clones[0].output_text, // Return standard deterministic output
        metrics: {
          gas_debited: "1.25 x402",
          audit_trace_id: data.audit_trace.telemetry_id
        }
      });

    } else {
      return res.status(403).json({ error: 'KCN_ERR: UNAUTHORIZED_ROLE' });
    }

  } catch (error: any) {
    return res.status(500).json({ error: `OIDC Router Failure: ${error.message}` });
  }
}
```

---

### Step 5: How to Run and Test Both Portals Locally
Once you have saved these files, you can simulate requests from both roles using terminal commands:

#### Test 1: Simulating Your Owner Portal (Unconstrained Discovery)
To mock your owner account, generate a JWT containing role `KCN_ROLE_SYSTEM_OWNER` and issue a request. The system will bypass shadow simulations and return unconstrained, deep insights:
```bash
curl -X POST "http://localhost:3000/api/request" \
  -H "Authorization: Bearer <owner_jwt_token>" \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Query the discovery laboratory for experimental semiconductor patterns."}'
```

#### Test 2: Simulating the Public Portal (Strict Compliance)
To mock a public user, generate a JWT containing role `KCN_ROLE_PUBLIC_USER` and submit a request. The system will force the request through the 4 shadow clones, evaluate the divergence score, and charge gas to the user's wallet:
```bash
curl -X POST "http://localhost:3000/api/request" \
  -H "Authorization: Bearer <public_jwt_token>" \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Design an optimized material compound for high-efficiency solar panel cells."}'
```

---

## SECTION 3: REPOSITORY ARCHIVE UPDATED

We have compiled this complete dual-portal deployment guide and saved it directly to your workspace at **`KCN_DUAL_PORTAL_DEPLOYMENT_GUIDE.md`**.

This completes the concrete engineering blueprint, giving you the exact Keycloak role setups, HashiCorp Vault client scripts, and Next.js middleware routers to operate your public-facing compliant sandbox alongside your private unconstrained discovery portal!
