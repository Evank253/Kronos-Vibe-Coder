import json
from services.interstellar_metamorphic_compiler import simulate_retrocausal_patch

def run_tachyonic_compiler_tests():
    print("=" * 80)
    print(" KCN-AKIIS TACHYONIC METAMORPHIC COMPILER - SYSTEM INTEGRITY CHECK")
    print("=" * 80)

    # --- TEST 1: COMPILING SAFE SYSTEM CODE ---
    print("[1/2] Compiling Standard Interstellar Science Instruction Set...")
    source_safe = """
def calculate_orbital_decay(radius):
    return radius * 0.9998
"""
    patched_safe, deployed_safe, logs_safe = simulate_retrocausal_patch(source_safe)
    print(f"  Source Code Length: {len(source_safe)}")
    print(f"  Patched Code Length: {len(patched_safe)}")
    print(f"  Retrocausal Patch Deployed: {deployed_safe}")
    assert not deployed_safe, "No retrocausal patch should deploy on safe physics calculations."
    print("  ✔ SAFE INTERSTELLAR COMPILATION: STABLE & NO PARADOXES.\n")

    # --- TEST 2: COMPILING VULNERABLE CODE WITH RETROCAUSAL PATCH ---
    print("[2/2] Compiling Code with Unbounded RAM allocation...")
    source_vulnerable = """
def allocate_sandbox_memory(request_size):
    new_ram = old_ram + request_size
    return new_ram
"""
    patched_vuln, deployed_vulnerable, logs_vuln = simulate_retrocausal_patch(source_vulnerable)
    print(f"  Source Code Length: {len(source_vulnerable)}")
    print(f"  Patched Code Length: {len(patched_vuln)}")
    print(f"  Retrocausal Patch Deployed: {deployed_vulnerable}")
    assert deployed_vulnerable, "Retrocausal patch should automatically deploy on unsafe memory requests."
    assert "Enforcing safety boundaries" in patched_vuln, "Patch did not inject the correct boundary instructions."
    
    print("\n  ✔ RETROCAUSAL METAMORPHIC BOUNDARY INJECTION: PERFECT.")
    print("-" * 80)
    print("✔ Tachyonic Metamorphic Compiler algorithms tested with 100% computational correctness!")
    print("=" * 80)

if __name__ == "__main__":
    run_tachyonic_compiler_tests()
