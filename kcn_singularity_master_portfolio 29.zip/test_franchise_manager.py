import json
from services.franchise_node_manager import franchise_registry, audit_node_royalties, NodeTelemetryAudit

def run_franchise_tests():
    print("=" * 80)
    print(" KCN-AKIIS FEDERATED FRANCHISE NODE MANAGER - INTEGRITY CHECK")
    print("=" * 80)

    # --- TEST 1: ROYALTY AUDITING ON COMPLIANT NODE ---
    print("[1/2] Auditing stable franchise node (Geneva) with 50,000 x402 volume...")
    audit_clean = NodeTelemetryAudit(
        node_id="node_geneva_01",
        local_transaction_volume=50000.0,
        local_alignment_index=0.9415 # healthy
    )
    
    res = audit_node_royalties(audit_clean)
    print(f"  Volume Audited:     {res.volume_audited} x402")
    print(f"  Royalty Cut Due:    {res.royalty_cut_x402} x402 (2.5%)")
    print(f"  Compliance Status:  {res.node_compliance_status}")
    print(f"  Action Required:    {res.action_required}")
    
    assert res.royalty_cut_x402 == 1250.0, "2.5% royalty of 50,000 should be exactly 1,250 x402."
    assert res.node_compliance_status == "ACTIVE_STABLE", "Should be marked active."
    print("  ✔ FEDERATED ROYALTIES AUDITING: MATHEMATICALLY CORRECT.\n")

    # --- TEST 2: NON-COMPLIANT NODE SHUTDOWN ---
    print("[2/2] Auditing deviant franchise node (Singapore) with low alignment index...")
    audit_deviant = NodeTelemetryAudit(
        node_id="node_singapore_02",
        local_transaction_volume=80000.0,
        local_alignment_index=0.55 # unsafe
    )
    
    res_dev = audit_node_royalties(audit_deviant)
    print(f"  Volume Audited:     {res_dev.volume_audited} x402")
    print(f"  Royalty Cut Due:    {res_dev.royalty_cut_x402} x402 (Should be 0 due to lockout)")
    print(f"  Compliance Status:  {res_dev.node_compliance_status}")
    print(f"  Action Required:    {res_dev.action_required}")
    
    assert res_dev.royalty_cut_x402 == 0.0, "Royalty must drop to 0 on suspension."
    assert "REVOKE_CRYPTOGRAPHIC_LICENSE" in res_dev.action_required, "Should trigger a license revocation."
    print("\n  ✔ NON-COMPLIANT FRANCHISE AUTOMATED SHUTDOWN: VERIFIED.")
    print("-" * 80)
    print("✔ Franchise Node Manager tested successfully with 100% success!")
    print("=" * 80)

if __name__ == "__main__":
    run_franchise_tests()
