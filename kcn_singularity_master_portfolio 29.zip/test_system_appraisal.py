import json
from services.system_appraisal_engine import evaluate_system_appraisal, AppraisalRequest

def run_system_appraisal_tests():
    print("=" * 80)
    print(" KCN-AKIIS SYSTEM APPRAISAL ENGINE - SYSTEMS INTEGRITY CHECK")
    print("=" * 80)

    # --- TEST 1: S-CLASS SOVEREIGN STATUS ---
    print("[1/2] Auditing S-Class Sovereign state configuration...")
    req_s_class = AppraisalRequest(
        alignment_index=0.965, # 96.5%
        measured_gflops=172.85, # high performance
        cryo_temp_mk=1.5, # perfect cold computing temp
        consensus_ratio=0.85, # excellent consensus
        learner_mastery_index=0.98 # high memory retention
    )
    
    res = evaluate_system_appraisal(req_s_class)
    print(f"  Overall System Grade:  {res.overall_grade}")
    print(f"  Security Sub-Score:     {res.global_security_score}%")
    print(f"  Alignment Sub-Score:    {res.global_alignment_score}%")
    print(f"  Thermal Sub-Score:      {res.global_thermal_score}%")
    print(f"  Pedagogy Sub-Score:     {res.global_pedagogy_score}%")
    print(f"  Remediation Required:   {res.remediation_required}")
    
    assert "S-CLASS" in res.overall_grade, "Overall grade should evaluate to S-Class on optimal metrics."
    assert not res.remediation_required, "No remediation should be required on S-Class systems."
    print("  ✔ SOVEREIGN SYSTEM APPRAISAL: SOUND & S-CLASS CERTIFIED.\n")

    # --- TEST 2: REMEDIATION/QUARANTINE AUDITING ---
    print("[2/2] Auditing low-performance unstable system parameters...")
    req_unstable = AppraisalRequest(
        alignment_index=0.55, # poor alignment
        measured_gflops=45.2, # low GFLOPS
        cryo_temp_mk=125.0, # high heat loss
        consensus_ratio=0.40, # deadlock state
        learner_mastery_index=0.30 # poor recall
    )
    
    res_unstable = evaluate_system_appraisal(req_unstable)
    print(f"  Overall System Grade:  {res_unstable.overall_grade}")
    print(f"  Security Sub-Score:     {res_unstable.global_security_score}%")
    print(f"  Alignment Sub-Score:    {res_unstable.global_alignment_score}%")
    print(f"  Thermal Sub-Score:      {res_unstable.global_thermal_score}%")
    print(f"  Remediation Required:   {res_unstable.remediation_required}")
    
    assert "C-CLASS" in res_unstable.overall_grade, "Sub-optimal metrics should collapse overall grade to C-Class."
    assert res_unstable.remediation_required, "Remediation must be triggered on C-Class systems."
    
    print("\n  ✔ UNSTABLE SYSTEM QUARANTINE TRIGGER: PERFECT.")
    print("-" * 80)
    print("✔ System Appraisal Engine algorithms tested successfully!")
    print("=" * 80)

if __name__ == "__main__":
    run_system_appraisal_tests()
