import json
from services.local_hardware_manager import run_local_boundary_audit

def run_local_manager_tests():
    print("=" * 80)
    print(" KCN-AKIIS LOCAL HARDWARE MANAGER - SYSTEMS INTEGRITY CHECK")
    print("=" * 80)

    # --- TEST 1: AIR-GAPPED BOUNDARY ---
    print("[1/2] Auditing air-gapped system boundary (connected = False)...")
    speed, p_local, net_state, action, logs = run_local_boundary_audit(
        outbound_bytes=0.0,
        connected=False,
        quant="4-bit"
    )
    
    print(f"  Token Speed:        {speed} TPS")
    print(f"  Privacy Coefficient: {p_local}")
    print(f"  Network Status:      {net_state}")
    print(f"  Boundary Action:     {action}")
    
    assert speed == 45.2, "Token speed should be 45.2 TPS for 4-bit quant."
    assert p_local == 1.0, "Privacy coefficient must be 1.0000 on air-gapped systems."
    assert "AIR-GAPPED" in net_state, "Should be marked air-gapped."
    print("  ✔ AIR-GAPPED LOCALHOAST BOUNDARY: SOUND & SECURED.\n")

    # --- TEST 2: OUTBOUND LEAK ATTEMPT INTERCEPTION ---
    print("[2/2] Auditing WAN connected leak attempt...")
    speed_leak, p_local_leak, net_state_leak, action_leak, logs_leak = run_local_boundary_audit(
        outbound_bytes=5000.0, # 5KB leak attempt
        connected=True,
        quant="4-bit"
    )
    
    print(f"  Network Status:      {net_state_leak}")
    print(f"  Boundary Action:     {action_leak}")
    print(f"  Privacy Coefficient: {p_local_leak}")
    
    assert "CONNECTED" in net_state_leak, "Should be marked connected."
    assert "INTERCEPT_AND_BLOCK" in action_leak, "Should trigger a block action on leaks."
    assert p_local_leak < 1.0, "Privacy index should drop slightly on leak attempts."
    print("\n  ✔ WAN LEAK INTERCEPTION AND BLOCKING: VERIFIED.")
    print("-" * 80)
    print("✔ Local Hardware Manager tested successfully with 100% success!")
    print("=" * 80)

if __name__ == "__main__":
    run_local_manager_tests()
