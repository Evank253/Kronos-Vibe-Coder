# KCN-SINGULARITY: LOVABLE DECOUPLING SPECIFICATION
## Separating Lovable's Visual Frontend from Your Private, Secure GitHub Backend

To achieve your goal of using **Lovable purely for generating the visual frontend** (having a visual preview on Lovable) while keeping your **backend code, secrets, and private repository completely unlinked and independent**, we implement a **Clean Client-Server Decoupling**.

By configuring the platform this way, Lovable operates purely as a "Static Visual Client." It does not contain any of your private backend logic, SMT solvers, or Vault configurations. Instead, it communicates with your self-hosted backend via standardized API endpoints.

Below is the exact developer specification and step-by-step instructions to configure Lovable and your GitHub repository for complete decoupling.

---

## SECTION 1: THE DECOUPLED ARCHITECTURE

```
 ┌────────────────────────────────────────┐       ┌────────────────────────────────────────┐
 │       LOVABLE FRONTEND CLOUD           │       │      YOUR PRIVATE GITHUB / LOCAL PC    │
 │       (Purely Visual Static Shell)     │       │      (Secure Core, Secrets, & Vault)   │
 ├────────────────────────────────────────┤       ├────────────────────────────────────────┤
 │                                        │       │                                        │
 │  - Marketing Landing Page (/)          │       │  - Master Swarm Orchestrator (Ray/Temp)│
 │  - Subscriber Chatbox UI (/portal)     │       │  - Z3 SMT Formal Safety Gate           │
 │  - Private Owner Cockpit UI (/sing)    │       │  - HashiCorp Vault Secrets Enclave     │
 │                                        │       │  - x402 Sovereign Economic Ledger      │
 │  * Routes API calls to:                │       │  - OpenSearch SIEM Logs & Wazuh        │
 │    process.env.NEXT_PUBLIC_API_URL     │       │                                        │
 └───────────────────┬────────────────────┘       └───────────────────▲────────────────────┘
                     │                                                │
                     └────────────── REST APIs over mTLS ─────────────┘
                              (e.g., http://localhost:8000)
```

---

## SECTION 2: WHAT TO TELL LOVABLE (THE DECOUPLING PROMPTS)

To ensure Lovable builds the frontend exactly according to this separated architecture, copy and paste these exact instructions into your Lovable prompt window:

```text
Build KCN-SINGULARITY purely as a Static Frontend Visual Client. 

Enforce the following decoupled architecture guidelines:
1. Do not build or run any backend python services, database connections, or secret handlers inside this Lovable build.
2. Build three clean, visual page views:
   - '/' (home): A beautiful marketing landing page explaining KCN-AKIIS.
   - '/portal': A subscriber-only chatbox interface.
   - '/singularity': A hidden owner control cockpit with live telemetry panels.
3. Configure all API fetch requests (such as public chat and owner discovery queries) to route to a configurable environment variable 'process.env.NEXT_PUBLIC_API_URL'.
4. In the local settings file, default 'NEXT_PUBLIC_API_URL' to 'http://localhost:8000' so the frontend automatically communicates with my locally hosted Python backend.
```

---

## SECTION 3: STEP-BY-STEP DECOUPLING & DEPLOYMENT FLOW

### Step 1: Let Lovable Generate the Frontend Visuals
1.  Feed the decoupling prompts (from Section 2) into Lovable.
2.  Lovable will generate the beautiful user interfaces for your public website (`/`), your subscriber portal (`/portal`), and your hidden owner workspace (`/singularity`).

### Step 2: Push the Code to Your GitHub
1.  Use Lovable's built-in Git integration to connect and push the generated code directly to your GitHub repository (e.g., `github.com/username/kcn-frontend`).
2.  **Unlink Lovable**: Once the push is successful, disconnect and unlink Lovable from your GitHub repository. Your code is now 100% yours, safely stored on GitHub, with zero runtime connections to Lovable.

### Step 3: Run Your Secure Backend Separately (Free & Local)
Because your backend is completely separate, you run it on your own computer with zero credit costs or public exposure:

1.  Clone your secure backend files from your private GitHub:
    ```bash
    git clone https://github.com/YOUR_USERNAME/kcn-singularity-backend.git
    cd kcn-singularity-backend
    ```
2.  Run your master unified Python script (FastAPI, Z3, and x402 ledger):
    ```bash
    python3 kcn_singularity_unified_system.py
    ```
    *This activates your local API gateway on `http://localhost:8000` to receive and process requests from your decoupled frontend.*

### Step 4: Configure the Frontend Environment Variable
To connect your decoupled frontend UI to your secure backend, set the API environment variable in your frontend project:

1.  Create a `.env.local` file in the root of your frontend project:
    ```text
    NEXT_PUBLIC_API_URL=http://localhost:8000
    ```
2.  Launch your local frontend development server:
    ```bash
    npm run dev
    ```
3.  **Access Your Unified Platform**: Open your browser to `http://localhost:3000`. Your visual pages will now securely load and communicate with your private local backend, completely free and completely isolated from Lovable!

---

## SECTION 4: DECOUPLING GUIDE CREATED IN WORKSPACE

We have compiled this complete decoupling guide and saved it directly to your workspace at **`KCN_LOVABLE_DECOUPLING_SPEC.md`**.

This completes the absolute separation blueprint, giving you the exact steps and prompt scripts to leverage Lovable's visual capabilities while keeping your core platform, secrets, and private repository 100% secure, unlinked, and independent!
