import json
from services.hero_swarm_controller import evaluate_swarm_consensus, ConsensusRequest

def run_hero_swarm_tests():
    print("=" * 80)
    print(" KCN-AKIIS HERO SWARM CONTROLLER - SYSTEMS INTEGRITY CHECK")
    print("=" * 80)

    # --- TEST 1: CONSENSUS AUDITING WITH QUARANTINE ---
    print("[1/2] Auditing dynamic agent voter structures with a compromised node...")
    req_compromised = ConsensusRequest(
        task_id="task_nuclear_thermodynamics_004",
        initiator_agent="athena",
        proposed_solution_hash="0xProposedSolutionHash_Athena_99ab",
        voter_agents=["agent_orion", "agent_sentinel", "agent_tutor", "agent_buggy_research"]
    )
    
    res = evaluate_swarm_consensus(req_compromised)
    print(f"  Total Voters Evaluated: {len(req_compromised.voter_agents)}")
    print(f"  Voter Consensus Ratio:  {res.consensus_ratio * 100}%")
    print(f"  Consensus Achieved:     {res.consensus_achieved}")
    print(f"  HERO Audit Decision:    {res.audit_decision}")
    print(f"  Active Quarantined Nodes: {res.active_quarantine_nodes}")
    
    assert res.consensus_achieved, "Consensus should still pass with 75% approval."
    assert "agent_buggy_research" in res.active_quarantine_nodes, "Compromised node should be quarantined."
    print("  ✔ HERO SWARM EXECUTIVE CONSENSUS PROCESS: PERFECT.\n")

    # --- TEST 2: DEADLOCK CONTAINMENT ---
    print("[2/2] Simulating total deadlock (voter ratio under 70%)...")
    req_deadlock = ConsensusRequest(
        task_id="task_untrusted_exploit_injection",
        initiator_agent="orion",
        proposed_solution_hash="0xSolution_0124",
        voter_agents=["agent_buggy_1", "agent_buggy_2", "agent_orion"]
    )
    res_deadlock = evaluate_swarm_consensus(req_deadlock)
    print(f"  Voter Consensus Ratio:  {res_deadlock.consensus_ratio * 100}%")
    print(f"  Consensus Achieved:     {res_deadlock.consensus_achieved}")
    print(f"  HERO Audit Decision:    {res_deadlock.audit_decision}")
    
    assert not res_deadlock.consensus_achieved, "Consensus should fail under 70% threshold."
    assert "SWARM_DEADLOCK" in res_deadlock.audit_decision, "Deadlock must trigger administrative halting."
    
    print("\n  ✔ HERO SWARM TIMELINE DEADLOCK ISOLATION: PERFECT.")
    print("-" * 80)
    print("✔ HERO Swarm executive controller algorithms tested successfully!")
    print("=" * 80)

if __name__ == "__main__":
    run_hero_swarm_tests()
