import time
import multiprocessing
from concurrent.futures import ThreadPoolExecutor
import numpy as np

def run_floating_point_stress_core(matrix_size: int, iterations: int):
    """
    Executes intensive, high-performance matrix multiplications
    to stress individual CPU cores and measure raw GFLOPS performance.
    """
    # Create two high-dimensional random float matrices
    A = np.random.rand(matrix_size, matrix_size).astype(np.float32)
    B = np.random.rand(matrix_size, matrix_size).astype(np.float32)
    
    # Each multiplication of size N requires 2 * N^3 operations
    flops_per_multiply = 2.0 * (matrix_size ** 3)
    total_flops = flops_per_multiply * iterations
    
    start_time = time.time()
    for _ in range(iterations):
        C = np.dot(A, B) # Execute GEMM matrix dot product
    end_time = time.time()
    
    elapsed = end_time - start_time
    gflops = (total_flops / elapsed) / 1e9 if elapsed > 0 else 0.0
    return elapsed, gflops

def run_master_stress_test():
    print("=" * 80)
    print(" KCN-AKIIS 'BEAST-MODE' MULTITHREADED CPU STRESS TEST & BENCHMARK")
    print("=" * 80)
    
    num_cores = multiprocessing.cpu_count()
    print(f"[SYSTEM DETECTED]: {num_cores} physical/logical CPU cores available.")
    
    matrix_size = 1500  # 1500 x 1500 matrix
    iterations = 20
    
    print(f"[STAGE 1/2] Warming up CPU cores (Matrix size: {matrix_size}x{matrix_size})...")
    time.sleep(0.5)
    
    # Run a single core warmup
    elapsed, gflops = run_floating_point_stress_core(matrix_size, 5)
    print(f"  ✔ Warmup complete. Single-core peak: {gflops:.2f} GFLOPS.")
    
    print(f"\n[STAGE 2/2] Booting parallel thread pool. Dispatching stress-tasks to {num_cores} cores...")
    time.sleep(0.5)
    
    start_global = time.time()
    results = []
    
    with ThreadPoolExecutor(max_workers=num_cores) as executor:
        # Launch parallel matrix multiplication jobs across all available cores
        futures = [executor.submit(run_floating_point_stress_core, matrix_size, iterations) for _ in range(num_cores)]
        for f in futures:
            results.append(f.result())
            
    end_global = time.time()
    global_elapsed = end_global - start_global
    
    # Calculate aggregate performance metrics
    avg_elapsed = sum(r[0] for r in results) / len(results)
    aggregate_gflops = sum(r[1] for r in results)
    
    print("\n" + "=" * 80)
    print("               KCN-AKIIS CPU STRESS TEST SCORECARD")
    print("=" * 80)
    print(f"  Total Processed Cores:          {num_cores}")
    print(f"  Matrix Multiplications per Core: {iterations}")
    print(f"  Average Core Execution Time:    {avg_elapsed:.4f} seconds")
    print(f"  Total Global Stress Duration:   {global_elapsed:.4f} seconds")
    print(f"  Aggregate Multi-Core Peak:      {aggregate_gflops:.2f} GFLOPS")
    print("=" * 80)
    print("\n✔ System benchmark executed with 100% computational load stability!")

if __name__ == "__main__":
    run_master_stress_test()
