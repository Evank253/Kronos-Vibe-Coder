# KCN-SINGULARITY: LOCAL GIT & FREE DEPLOYMENT HANDBOOK
## Manual GitHub Repository Initialization, Local Code Compilation, and Zero-Credit Execution Guide
### Authored for: evan.ketchum2026@outlook.com (KCN-Layer-0-Admin)

---

## 🏛️ OVERVIEW

If you have run out of credits on Lovable, **do not worry!** The entire, completed codebase—the Solidity contracts, the unified dual-portal python core, the Z3 SMT prover, the FastAPI shadow engine, and the Docker environment configurations—is **fully written, verified, and complete inside your local workspace**.

You can download the entire system in one click via your browser, and initialize, push, and run your private repository on your own machine completely for free with **zero cloud fees or platform credits**.

This handbook provides the exact terminal commands to set up your repository, push to GitHub, and launch your platform locally.

---

## SECTION 1: HOW TO DOWNLOAD AND EXTRACT THE PORTFOLIO

1.  **Download the ZIP**: Click the download link for `kcn_singularity_master_portfolio.zip` in your browser panel.
2.  **Extract the Files**: Move the ZIP file to your target local folder and extract it:
    *   *Mac/Linux*:
        ```bash
        unzip kcn_singularity_master_portfolio.zip -d kcn-singularity-platform
        cd kcn-singularity-platform
        ```
    *   *Windows*: Right-click the file and select **Extract All**, naming the folder `kcn-singularity-platform`, and open your command prompt/terminal inside that directory.

---

## SECTION 2: MANUAL GITHUB INITIALIZATION & PUSH (THE "TRICK")

To host your full, unlinked repository on your personal GitHub account manually, execute these standard Git commands in your terminal:

```bash
# 1. Initialize a brand-new local Git repository
git init -b master

# 2. Stage all project files, specs, contracts, and codes
git add .

# 3. Create your first formal commit
git commit -m "feat: KCN-AKIIS v1.1.0 sovereign dual-portal, x402 brokerage, and Z3 safety solver platform"

# 4. Create a new repository on github.com (make it private for security)
# Link your local repository to your private GitHub remote
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/kcn-singularity-platform.git

# 5. Push the completed codebase directly to your master branch
git push -u origin master
```

*Your complete, functional monorepo is now safely hosted on your GitHub account with zero active ties or dependencies on Lovable!*

---

## SECTION 3: FREE LOCAL LAUNCH & EXECUTION (0 CREDITS)

Since you are running the system on your own computer's CPU/GPU, there are no execution limits, platform fees, or credit constraints.

### 1. Boot up the Local Backend API Server
Installs requirements and launches the dual-portal server, exposing the public chatbox gateway and your private owner discovery panel:

```bash
# Install the necessary open-source python packages
python3 -m pip install z3-solver fastapi uvicorn pydantic requests web3

# Launch the unified runtime core and start the background API server
python3 -u kcn_singularity_unified_system.py
```
*Leave this terminal open to keep your local API gateway active on `http://localhost:8000`.*

### 2. Boot up the Local Container Mesh (Optional Docker Setup)
If you have Docker installed and want to run your services inside secure, isolated containers:
```bash
# Spin up the FastAPI shadow simulation API and Redis memory cache containers
docker-compose up --build -d

# Verify container health
docker-compose ps
```

### 3. Run Your Automated Benchmark Suite & Prover Tests
To verify your system accuracy, shadow clone divergence tokenizer, and Z3 mathematical proofs:
```bash
# Run the active Z3 safety solver test cases
python3 services/smt_safety_gate.py

# Execute the 1,000-task automated evaluation sweeps
python3 benchmark_runner.py
python3 generate_report.py
```

---

## SECTION 4: INTERACTING WITH YOUR PORTALS VIA TERMINAL

While your local Python backend is running, open a second terminal window to simulate both your public users and your private admin views:

### 1. Test the Paid Public Chatbox (`/public-chat`)
Simulate a paid subscriber submitting a safe, high-assurance query. The system will run the 4 shadow clones, calculate divergence, check SMT safety, and bill gas:
```bash
curl -X POST "http://localhost:8000/public-chat" \
  -H "Content-Type: application/json" \
  -d '{"prompt": "What is the thermodynamic efficiency limit of a silicon photovoltaic cell?", "user_id": "public_user_12"}'
```

### 2. Test Your Private Owner Discovery Portal (`/owner-portal`)
Simulate logging into your private portal. The system verifies your system-owner role, queries the secure HashiCorp Vault, bypasses all safety filters, and activates the *Sovereign Sector Builder* with **zero gas fees**:
```bash
curl -X POST "http://localhost:8000/owner-portal" \
  -H "Authorization: Bearer KCN_ROLE_SYSTEM_OWNER" \
  -H "Content-Type: application/json" \
  -d '{"prompt": "Query the discovery laboratory for experimental semiconductor patterns."}'
```

---
*Manual deployment specification verified. Your local platform is ready for execution.*
