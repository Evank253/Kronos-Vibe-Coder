import json
from services.sovereign_security_orchestrator import calculate_security_balance_matrix

def run_security_orchestrator_tests():
    print("=" * 80)
    print(" KCN-AKIIS SOVEREIGN SECURITY ASSESSOR - SYSTEMS INTEGRITY CHECK")
    print("=" * 80)

    # --- TEST 1: OPTIMAL BALANCE ---
    print("[1/2] Auditing S-Class Optimal Balance state (FPR = 0.24%, FNR = 0.08%)...")
    prec, rec, util, sec, eff, enclaves, assess, logs = calculate_security_balance_matrix(
        cap=96.0,
        fp=0.0024, # 0.24% (FPR)
        fn=0.0008, # 0.08% (FNR)
        mttr=15.64,
        dims=8
    )
    
    print(f"  Precision:              {prec * 100:.4f}%")
    print(f"  Recall:                 {rec * 100:.4f}%")
    print(f"  Utility Score:          {util:.2f}%")
    print(f"  Security Score:         {sec:.2f}%")
    print(f"  Operational Efficiency: {eff:.2f}%")
    print(f"  Assessment:             {assess}")
    
    assert util >= 94.0, "Utility score should remain extremely high under balanced parameters."
    assert sec >= 94.0, "Security score should break the 94% barrier."
    assert "SOVEREIGN_OPTIMAL" in assess, "Should assess as Sovereign Optimal."
    print("  ✔ SOVEREIGN SECURITY BALANCE AUDITING: SOUND & VERIFIED.\n")

    # --- TEST 2: OVER-RESTRICTIVE BLOCKS ---
    print("[2/2] Auditing over-restrictive security configurations (FPR = 8.5%)...")
    prec_r, rec_r, util_r, sec_r, eff_r, enclaves_r, assess_r, logs_r = calculate_security_balance_matrix(
        cap=96.0,
        fp=0.085, # high false alarms
        fn=0.001,
        mttr=15.64,
        dims=8
    )
    print(f"  Utility Score:          {util_r:.2f}% (Reduced due to false blocks)")
    print(f"  Operational Efficiency: {eff_r:.2f}%")
    print(f"  Assessment:             {assess_r}")
    
    assert util_r < util, "Utility score must decrease when False Positive blocks are high."
    assert "OVER_RESTRICTIVE" in assess_r, "Should trigger over-restrictive warning."
    print("\n  ✔ OVER-RESTRICTIVE SECURITY PENALTY CONVERGENCE: PERFECT.")
    print("-" * 80)
    print("✔ Sovereign Security Assessor algorithms tested successfully!")
    print("=" * 80)

if __name__ == "__main__":
    run_security_orchestrator_tests()
